// مهنتي — واجهة الويب (PWA). بدون أطر خارجية ولا خطوة بناء.
const $ = (s, r = document) => r.querySelector(s);
const view = $('#view');
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const nf = new Intl.NumberFormat('ar-SA');
const money = (n) => `${nf.format(n)} ر.س`;
const initial = (n) => esc([...(n || '؟')][0]);

const S = { token: localStorage.getItem('token'), user: null, cfg: null, es: null, unread: 0, timers: [] };

/* ---------- API ---------- */
async function api(path, { method = 'GET', body } = {}) {
  const r = await fetch('/api' + path, {
    method, headers: { 'content-type': 'application/json', ...(S.token ? { authorization: 'Bearer ' + S.token } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  const j = await r.json().catch(() => ({}));
  if (r.status === 401 && S.token) { logout(false); }
  if (!r.ok) throw new Error(j.error || 'تعذر تنفيذ الطلب');
  return j;
}
function toast(msg, err = false) {
  const t = document.createElement('div');
  t.className = 'toast' + (err ? ' err' : ''); t.textContent = msg; document.body.append(t);
  setTimeout(() => t.remove(), 3800);
}
const guard = (fn) => async (...a) => { try { return await fn(...a); } catch (e) { toast(e.message, true); } };

/* ---------- الجلسة والإشعارات ---------- */
async function boot() {
  S.cfg = await api('/config');
  if (S.token) { try { S.user = await api('/me'); connectEvents(); } catch { S.token = null; localStorage.removeItem('token'); } }
  if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(() => {});
  window.addEventListener('hashchange', route);
  route();
}
function setSession(token, user) {
  S.token = token; S.user = user; localStorage.setItem('token', token); connectEvents();
}
function logout(go = true) {
  S.token = null; S.user = null; localStorage.removeItem('token'); S.es?.close(); S.es = null;
  if (go) location.hash = '#/';
  route();
}
const NOTIF = {
  new_request: (p) => `طلب جديد في منطقتك: ${p.title}`, new_bid: (p) => `عرض جديد على طلبك: ${money(p.price)}`,
  outbid: (p) => `تم تجاوز عرضك — أقل سعر الآن ${money(p.price)}`, bid_won: (p) => `🎉 فزت بالطلب بسعر ${money(p.price)}`,
  bid_lost: () => 'انتهى المزاد وفاز عرض أقل', request_awarded: (p) => `تم إرساء طلبك على الأقل سعراً ${money(p.price)}`,
  request_expired: () => 'انتهى وقت طلبك بدون عروض', request_status: (p) => `تحديث حالة الطلب: ${STATUS[p.status]?.label || ''}`,
  request_cancelled: () => 'تم إلغاء طلب كان مرسى عليك', tech_approved: () => '✅ تم اعتماد حسابك كفني', tech_rejected: () => 'تم رفض توثيق حسابك، راجع السبب',
};
function connectEvents() {
  S.es?.close();
  const es = new EventSource('/api/events?token=' + encodeURIComponent(S.token));
  S.es = es;
  for (const type of Object.keys(NOTIF)) es.addEventListener(type, (e) => {
    const p = JSON.parse(e.data);
    toast(NOTIF[type](p)); S.unread++; $('#bell .dot').hidden = false;
    if (type === 'tech_approved' || type === 'tech_rejected') refreshMe().then(route);
    else if (/#\/(r\/|requests|tech)/.test(location.hash) || location.hash === '#/') route(true);
  });
}
async function refreshMe() { S.user = await api('/me'); }

/* ---------- الراوتر ---------- */
const STATUS = {
  open: { label: 'مفتوح للعروض', cls: 'gold' }, awarded: { label: 'تم الإرساء', cls: '' }, on_the_way: { label: 'الفني في الطريق', cls: '' },
  arrived: { label: 'وصل الفني', cls: '' }, in_progress: { label: 'جارٍ العمل', cls: '' }, completed: { label: 'مكتمل', cls: '' },
  cancelled: { label: 'ملغي', cls: 'red' }, expired: { label: 'انتهى بدون عروض', cls: 'gray' },
};
const FLOW = ['awarded', 'on_the_way', 'arrived', 'in_progress', 'completed'];
const NEXT = { awarded: ['on_the_way', 'أنا في الطريق'], on_the_way: ['arrived', 'وصلت إلى الموقع'], arrived: ['in_progress', 'بدء العمل'], in_progress: ['completed', 'تم إنهاء العمل'] };

const ROUTES = [
  [/^#\/?$/, home], [/^#\/login$/, login], [/^#\/new\/([\w-]+)$/, newRequest], [/^#\/requests$/, myRequests],
  [/^#\/r\/([\w-]+)$/, requestPage], [/^#\/nearby$/, nearby], [/^#\/profile$/, profile], [/^#\/t\/([\w-]+)$/, techPage],
  [/^#\/tech$/, techHome], [/^#\/tech\/setup$/, techSetup], [/^#\/wallet$/, wallet], [/^#\/admin$/, admin],
];
let cleanup = [];
async function route(silent = false) {
  cleanup.forEach((f) => f()); cleanup = [];
  S.timers.forEach(clearInterval); S.timers = [];
  const h = location.hash || '#/';
  renderNav();
  const [, fn] = ROUTES.find(([rx]) => rx.test(h)) || [null, home];
  const args = (h.match(ROUTES.find(([rx]) => rx.test(h))?.[0] || /x/) || []).slice(1);
  if (!silent) view.innerHTML = '<div class="spinner"></div>';
  $('#bell').hidden = !S.user;
  try { await fn(...args); } catch (e) { view.innerHTML = `<div class="empty"><div class="ic">⚠️</div><p>${esc(e.message)}</p><a class="btn" href="#/">الرئيسية</a></div>`; }
  startTimers();
  if (!silent) scrollTo(0, 0);
}
function renderNav() {
  const h = location.hash || '#/', role = S.user?.role;
  const items = !S.user ? [['#/', '🏠', 'الرئيسية'], ['#/nearby', '🗺️', 'القريبون'], ['#/login', '👤', 'دخول']]
    : role === 'technician' ? [['#/tech', '📋', 'الطلبات'], ['#/wallet', '💰', 'المحفظة'], ['#/profile', '👤', 'حسابي']]
    : role === 'admin' ? [['#/admin', '🛡️', 'الإدارة'], ['#/profile', '👤', 'حسابي']]
    : [['#/', '🏠', 'الرئيسية'], ['#/requests', '📄', 'طلباتي'], ['#/nearby', '🗺️', 'القريبون'], ['#/profile', '👤', 'حسابي']];
  $('#nav').innerHTML = items.map(([href, ic, t]) => `<a href="${href}" class="${h === href || (href !== '#/' && h.startsWith(href) && href.length > 3) ? 'on' : ''}"><span>${ic}</span><span>${t}</span></a>`).join('');
}
function startTimers() {
  const tick = () => document.querySelectorAll('[data-deadline]').forEach((el) => {
    const ms = +el.dataset.deadline - (Date.now() + (S.skew || 0));
    if (ms <= 0) { el.textContent = 'انتهى الوقت'; el.classList.add('late'); return; }
    const s = Math.floor(ms / 1000), h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), x = s % 60;
    el.textContent = (h ? h + ':' : '') + String(m).padStart(2, '0') + ':' + String(x).padStart(2, '0');
    el.classList.toggle('late', ms < 60000);
  });
  tick(); if (document.querySelector('[data-deadline]')) S.timers.push(setInterval(tick, 1000));
}
const needLogin = () => { if (!S.user) { sessionStorage.setItem('back', location.hash); location.hash = '#/login'; return true; } };

/* ---------- الدخول ---------- */
async function login() {
  if (S.user) { location.hash = '#/'; return; }
  let phone = '', isNew = false;
  const step1 = () => {
    view.innerHTML = `<div class="card" style="max-width:460px;margin:20px auto"><h1>تسجيل الدخول</h1><p class="mute">أدخل رقم جوالك وسنرسل لك رمز التحقق.</p>
      <label class="field"><span>رقم الجوال</span><input id="ph" type="tel" inputmode="tel" placeholder="05xxxxxxxx" autocomplete="tel" dir="ltr"></label>
      <button class="btn block" id="go">إرسال الرمز</button></div>`;
    $('#go').onclick = guard(async () => {
      phone = $('#ph').value; const r = await api('/auth/otp', { method: 'POST', body: { phone } });
      isNew = r.new_user; step2(r.dev_code);
    });
  };
  const step2 = (dev) => {
    view.innerHTML = `<div class="card" style="max-width:460px;margin:20px auto"><h1>رمز التحقق</h1>
      <p class="mute">أُرسل الرمز إلى ${esc(phone)}${dev ? ` <b>(تجريبي: ${esc(dev)})</b>` : ''}</p>
      <label class="field"><span>الرمز (6 أرقام)</span><input id="code" inputmode="numeric" maxlength="6" autocomplete="one-time-code" dir="ltr"></label>
      ${isNew ? `<label class="field"><span>الاسم</span><input id="nm" maxlength="60" autocomplete="name"></label>
      <div class="field"><span>أنا</span><div class="chips" id="role"><span class="chip on" data-r="customer">عميل أبحث عن فني</span><span class="chip" data-r="technician">فني أقدّم خدماتي</span></div></div>` : ''}
      <button class="btn block" id="ok">تأكيد</button><p class="mute" style="text-align:center"><a href="#" id="back">تغيير الرقم</a></p></div>`;
    let role = 'customer';
    $('#role')?.addEventListener('click', (e) => { const c = e.target.closest('.chip'); if (!c) return; role = c.dataset.r; $('#role').querySelectorAll('.chip').forEach((x) => x.classList.toggle('on', x === c)); });
    $('#back').onclick = (e) => { e.preventDefault(); step1(); };
    $('#ok').onclick = guard(async () => {
      const r = await api('/auth/verify', { method: 'POST', body: { phone, code: $('#code').value, name: $('#nm')?.value, role } });
      setSession(r.token, r.user);
      const back = sessionStorage.getItem('back'); sessionStorage.removeItem('back');
      location.hash = r.user.role === 'technician' ? (r.user.tech?.has_id ? '#/tech' : '#/tech/setup') : r.user.role === 'admin' ? '#/admin' : back || '#/';
      route();
    });
  };
  step1();
}

/* ---------- الرئيسية (عميل) ---------- */
async function home() {
  if (S.user?.role === 'technician') return (location.hash = '#/tech');
  if (S.user?.role === 'admin') return (location.hash = '#/admin');
  const draw = (q = '') => {
    const list = S.cfg.categories.filter((c) => c.name.includes(q.trim()));
    $('#cats').innerHTML = list.map((c) => `<a class="cat" href="#/new/${c.id}"><div class="ic">${c.icon}</div><b>${esc(c.name)}</b><small>اطلب الآن ←</small></a>`).join('') || '<div class="empty">لا نتائج</div>';
  };
  view.innerHTML = `<div class="hero"><h1>ابحث عن حرفي موثوق</h1><p>انشر طلبك والفنيون يتنافسون، والأقل سعراً يفوز</p>
    <div class="search">🔍<input id="q" placeholder="ابحث عن حرفي..." aria-label="بحث"></div></div>
    <a class="banner" href="#/nearby"><span class="ic">🗺️</span><span><b>فنيون قريبون منك الآن</b><small>خلال ١٠ كم · اطلب مباشرة بدون مزاد</small></span></a>
    <h2>التصنيفات</h2><div class="grid-cat" id="cats"></div>
    <h2>كيف يعمل؟</h2><div class="card gold">① انشر طلبك مع الصور والموقع<br>② فنيو منطقتك يرسلون أسعارهم ويخفضونها للمنافسة<br>③ عند انتهاء الوقت يفوز <b>الأقل سعراً</b> وتُفتح بيانات التواصل<br>④ تابع الفني حتى الوصول ثم قيّمه</div>`;
  draw(); $('#q').oninput = (e) => draw(e.target.value);
}

/* ---------- طلب جديد ---------- */
function geo() {
  return new Promise((res, rej) => {
    if (!navigator.geolocation) return rej(new Error('المتصفح لا يدعم تحديد الموقع'));
    navigator.geolocation.getCurrentPosition((p) => res({ lat: p.coords.latitude, lng: p.coords.longitude }), () => rej(new Error('تعذر تحديد موقعك، اختر المنطقة يدوياً')), { enableHighAccuracy: true, timeout: 10000 });
  });
}
async function toJpegB64(file, max = 1280) {
  const bmp = await createImageBitmap(file);
  const k = Math.min(1, max / Math.max(bmp.width, bmp.height));
  const c = document.createElement('canvas'); c.width = Math.round(bmp.width * k); c.height = Math.round(bmp.height * k);
  c.getContext('2d').drawImage(bmp, 0, 0, c.width, c.height);
  return c.toDataURL('image/jpeg', 0.82).split(',')[1];
}
async function upload(file, kind) { return (await api('/uploads', { method: 'POST', body: { data: await toJpegB64(file), kind } })).url; }

async function newRequest(catId) {
  if (needLogin()) return;
  if (S.user.role !== 'customer') throw new Error('هذه الصفحة للعملاء فقط');
  const cat = S.cfg.categories.find((c) => c.id === catId); if (!cat) throw new Error('الخدمة غير معروفة');
  const direct = new URLSearchParams(location.search).get('tech') || sessionStorage.getItem('direct_' + catId);
  let loc = null, photos = [];
  view.innerHTML = `<h1>${cat.icon} طلب ${esc(cat.name)}</h1>${direct ? '<div class="card gold">طلب مباشر لفني محدد (بدون مزاد)</div>' : ''}
    <div class="card"><label class="field"><span>عنوان مختصر</span><input id="t" maxlength="80" placeholder="مثال: المكيف لا يبرّد"></label>
    <label class="field"><span>وصف المشكلة</span><textarea id="d" maxlength="1000" placeholder="اشرح المشكلة بالتفصيل ليتمكن الفنيون من التسعير بدقة"></textarea></label>
    <div class="field"><span>صور (اختياري، حتى 5)</span><div class="photos" id="ph"></div><input type="file" id="f" accept="image/*" multiple hidden><button class="btn ghost sm" id="addp" type="button">📷 إضافة صور</button></div>
    <div class="field"><span>الموقع</span><div class="row wrap"><button class="btn ghost sm" id="loc" type="button">📍 استخدم موقعي</button><span class="mute" id="locs">لم يُحدد بعد</span></div>
    <select id="z" style="margin-top:8px;width:100%;border:1.5px solid var(--line);border-radius:12px;padding:12px;min-height:48px"><option value="">أو اختر مدينتك</option>${S.cfg.zones.map((z) => `<option value="${z.id}">${esc(z.name)}</option>`).join('')}</select></div>
    <label class="field"><span>وصف العنوان (حي/شارع/معلم)</span><input id="a" maxlength="200"></label>
    ${direct ? '' : `<label class="field"><span>مدة استقبال العروض</span><select id="m">${S.cfg.durations.map((m) => `<option value="${m}" ${m === 60 ? 'selected' : ''}>${m < 60 ? m + ' دقيقة' : m === 1440 ? 'يوم كامل' : m / 60 + ' ساعة'}</option>`).join('')}</select></label>`}
    <button class="btn block" id="send">${direct ? 'إرسال للفني' : 'نشر الطلب'}</button></div>`;
  const drawP = () => { $('#ph').innerHTML = photos.map((u) => `<img src="${esc(u)}" alt="">`).join(''); };
  $('#addp').onclick = () => $('#f').click();
  $('#f').onchange = guard(async (e) => {
    for (const f of [...e.target.files].slice(0, 5 - photos.length)) photos.push(await upload(f, 'public'));
    drawP();
  });
  $('#loc').onclick = guard(async () => { loc = await geo(); $('#locs').textContent = '✅ تم تحديد موقعك'; $('#z').value = ''; });
  $('#send').onclick = guard(async () => {
    const zid = $('#z').value;
    if (!loc && zid) { const z = S.cfg.zones.find((x) => x.id === zid); loc = { lat: z.lat, lng: z.lng }; }
    if (!loc) throw new Error('حدد موقعك أو اختر مدينتك');
    const btn = $('#send'); btn.disabled = true;
    try {
      const r = await api('/requests', { method: 'POST', body: { category_id: catId, title: $('#t').value || undefined, description: $('#d').value, photos, ...loc, zone_id: zid || undefined, address: $('#a').value || undefined, duration_minutes: +($('#m')?.value || 60), direct_tech_id: direct || undefined } });
      sessionStorage.removeItem('direct_' + catId);
      toast(r.notified ? `وصل طلبك إلى ${r.notified} فني في منطقتك` : 'تم نشر الطلب، لا يوجد فنيون مسجلون بعد في منطقتك');
      location.hash = '#/r/' + r.id;
    } finally { btn.disabled = false; }
  });
}

/* ---------- القوائم ---------- */
function reqCard(r) {
  const st = STATUS[r.status] || {};
  return `<a class="card" href="#/r/${r.id}" style="display:block;color:inherit"><div class="row"><span style="font-size:28px">${r.category_icon}</span><div><b>${esc(r.title)}</b><div class="mute">${esc(r.category_name)} · ${esc(r.zone_name)}</div></div><span class="sp"></span><span class="tag ${st.cls}">${st.label}</span></div>
    <div class="row wrap" style="margin-top:10px"><span class="mute">${r.bids_count} عرض</span>${r.lowest_price != null ? `<span class="tag">الأقل ${money(r.final_price ?? r.lowest_price)}</span>` : ''}<span class="sp"></span>${r.status === 'open' ? `⏱ <span class="timer" data-deadline="${r.deadline_at}"></span>` : ''}</div></a>`;
}
async function myRequests() {
  if (needLogin()) return;
  const { requests } = await api('/requests');
  view.innerHTML = `<h1>طلباتي</h1>${requests.map(reqCard).join('') || '<div class="empty"><div class="ic">📄</div><p>لا توجد طلبات بعد</p><a class="btn" href="#/">اطلب خدمة</a></div>'}`;
}

/* ---------- صفحة الطلب ---------- */
async function requestPage(id) {
  if (needLogin()) return;
  const r = await api('/requests/' + id);
  S.skew = r.now - Date.now();
  const me = S.user, st = STATUS[r.status] || {}, isTech = me.role === 'technician';
  const idx = FLOW.indexOf(r.status);
  const steps = FLOW.map((s, i) => `<div class="step ${i < idx || r.status === 'completed' ? 'done' : i === idx ? 'cur' : ''}"><i>${i < idx || r.status === 'completed' ? '✓' : i + 1}</i>${STATUS[s].label}</div>`).join('');
  const bids = r.bids.map((b) => `<div class="bid ${b.is_winner ? 'win' : b.is_lowest && r.status === 'open' ? 'low' : ''}">
    ${b.tech_avatar ? `<img class="avatar" src="${esc(b.tech_avatar)}" alt="">` : `<div class="avatar">${initial(b.tech_name)}</div>`}
    <div><a href="#/t/${b.tech_id}"><b>${esc(b.tech_name)}</b></a> ${b.mine ? '<span class="tag gold">عرضي</span>' : ''}${b.is_lowest ? ' <span class="tag">الأقل</span>' : ''}${b.is_winner ? ' <span class="tag gold">🏆 الفائز</span>' : ''}
    <div class="mute">${b.rating ? '★ ' + b.rating + ` (${b.rating_count})` : 'جديد'}${b.warranty_days ? ' · ضمان ' + b.warranty_days + ' يوم' : ''}${b.eta_minutes ? ' · يصل خلال ' + b.eta_minutes + ' د' : ''}</div>${b.note ? `<div class="mute">${esc(b.note)}</div>` : ''}</div>
    <div class="price">${money(b.price)}</div></div>`).join('') || '<div class="empty">لا توجد عروض بعد… سيصلك إشعار فور وصول أول عرض</div>';

  let actions = '';
  if (r.is_owner) {
    if (r.status === 'open') actions = r.mode === 'direct'
      ? `<button class="btn block" data-act="accept" ${r.bids_count ? '' : 'disabled'}>قبول عرض الفني</button>`
      : `<button class="btn dark block" data-act="close" ${r.bids_count ? '' : 'disabled'}>إنهاء المزاد الآن وإرساؤه على الأقل سعراً</button>`;
    if (['open', 'awarded'].includes(r.status)) actions += `<button class="btn danger block" style="margin-top:8px" data-act="cancel">إلغاء الطلب</button>`;
  }
  let techBox = '';
  if (r.tech_phone && r.is_owner) techBox = `<div class="card gold"><b>الفني: ${esc(r.tech_name)}</b><div class="row" style="margin-top:8px"><a class="btn sm" href="tel:${esc(r.tech_phone)}">📞 اتصال</a><a class="btn ghost sm" href="https://wa.me/${esc(r.tech_phone.replace('+', ''))}" target="_blank" rel="noopener">واتساب</a><span class="mute" dir="ltr">${esc(r.tech_phone)}</span></div><p class="mute">الضمان: ${r.warranty_days || 0} يوم · السعر النهائي: ${money(r.final_price)}</p></div>`;
  let custBox = '';
  if (isTech && r.customer_phone) custBox = `<div class="card gold"><b>العميل: ${esc(r.customer_name)}</b><div class="row" style="margin-top:8px"><a class="btn sm" href="tel:${esc(r.customer_phone)}">📞 اتصال</a><a class="btn ghost sm" target="_blank" rel="noopener" href="https://www.google.com/maps?q=${r.lat},${r.lng}">📍 فتح الموقع</a><span class="mute" dir="ltr">${esc(r.customer_phone)}</span></div>${r.address ? `<p>${esc(r.address)}</p>` : ''}</div>`;
  let techAct = '';
  if (isTech && r.awarded_tech_id === me.id && NEXT[r.status]) techAct = `<button class="btn block" data-act="status" data-s="${NEXT[r.status][0]}">${NEXT[r.status][1]}</button>`;

  let bidForm = '';
  if (isTech && r.status === 'open') {
    const mine = r.my_bid;
    bidForm = `<div class="card"><h2 style="margin-top:0">${mine ? 'اخفض سعرك للمنافسة' : 'قدّم سومتك'}</h2>
      ${r.lowest_price != null ? `<p class="mute">أقل سعر حالياً: <b>${money(r.lowest_price)}</b>${mine ? ` · سعرك ${money(mine.price)} (يمكن الخفض فقط)` : ''}</p>` : ''}
      <label class="field"><span>السعر (ر.س)</span><input id="bp" type="number" inputmode="numeric" min="10" ${mine ? `max="${mine.price - 1}"` : ''} placeholder="${mine ? mine.price - 1 : ''}"></label>
      <div class="row"><label class="field sp"><span>الضمان</span><select id="bw">${[0, 1, 3, 7, 30, 90].map((d) => `<option value="${d}" ${(mine?.warranty_days ?? 0) === d ? 'selected' : ''}>${d ? d + ' يوم' : 'بدون'}</option>`).join('')}</select></label>
      <label class="field sp"><span>الوصول خلال (دقيقة)</span><input id="be" type="number" inputmode="numeric" value="${mine?.eta_minutes ?? ''}"></label></div>
      <label class="field"><span>ملاحظة</span><input id="bn" maxlength="300" value="${esc(mine?.note ?? '')}"></label>
      <button class="btn block" data-act="bid">${mine ? 'تحديث السعر' : 'إرسال العرض'}</button></div>`;
  }
  let review = '';
  if (r.is_owner && r.status === 'completed') review = r.review
    ? `<div class="card"><b>تقييمك</b><div class="stars">${'★'.repeat(r.review.stars)}${'☆'.repeat(5 - r.review.stars)}</div><p>${esc(r.review.comment || '')}</p></div>`
    : `<div class="card"><h2 style="margin-top:0">قيّم الفني</h2><div class="stars" id="stars">${[1, 2, 3, 4, 5].map((n) => `<button data-n="${n}" aria-label="${n}">★</button>`).join('')}</div>
      <div class="chips" id="tags" style="margin:10px 0">${S.cfg.review_tags.map((t) => `<span class="chip">${esc(t)}</span>`).join('')}</div>
      <label class="field"><span>تعليق</span><input id="rc" maxlength="500"></label><button class="btn block" data-act="review">إرسال التقييم</button></div>`;
  const complaint = (r.is_owner || r.awarded_tech_id === me.id) && r.awarded_tech_id ? `<p style="text-align:center"><a href="#" data-act="complain" class="mute">⚠️ تقديم شكوى على هذا الطلب</a></p>` : '';

  view.innerHTML = `<a href="${isTech ? '#/tech' : '#/requests'}" class="mute">→ رجوع</a>
    <div class="cols"><div><div class="card"><div class="row"><span style="font-size:32px">${r.category_icon}</span><div><h1 style="margin:0;font-size:20px">${esc(r.title)}</h1><div class="mute">${esc(r.category_name)} · ${esc(r.zone_name)}</div></div><span class="sp"></span><span class="tag ${st.cls}">${st.label}</span></div>
      <p>${esc(r.description)}</p>${r.photos.length ? `<div class="photos">${r.photos.map((p) => `<a href="${esc(p)}" target="_blank"><img src="${esc(p)}" alt=""></a>`).join('')}</div>` : ''}
      ${r.status === 'open' ? `<div class="row" style="margin-top:12px"><span>⏱ ينتهي خلال</span><span class="timer big" data-deadline="${r.deadline_at}"></span><span class="sp"></span>${r.lowest_price != null ? `<div><div class="mute">أقل سعر</div><div class="price" style="color:var(--ok)">${money(r.lowest_price)}</div></div>` : ''}</div>` : ''}
      ${['expired', 'cancelled'].includes(r.status) ? '' : `<div class="steps">${steps}</div>`}</div>
      ${techBox}${custBox}${techAct ? `<div style="margin-bottom:12px">${techAct}</div>` : ''}${review}</div>
    <div>${bidForm}<h2>العروض (${r.bids_count})</h2>${isTech && r.status === 'open' && !r.my_bid ? '' : ''}${bids}<div style="margin-top:12px">${actions}</div>${complaint}</div></div>`;

  // الأحداث
  let stars = 0; const tags = new Set();
  $('#stars')?.addEventListener('click', (e) => { const b = e.target.closest('button'); if (!b) return; stars = +b.dataset.n; $('#stars').querySelectorAll('button').forEach((x) => x.classList.toggle('on', +x.dataset.n <= stars)); });
  $('#tags')?.addEventListener('click', (e) => { const c = e.target.closest('.chip'); if (!c) return; c.classList.toggle('on'); c.classList.contains('on') ? tags.add(c.textContent) : tags.delete(c.textContent); });
  view.onclick = guard(async (e) => {
    const b = e.target.closest('[data-act]'); if (!b) return; e.preventDefault();
    const act = b.dataset.act, post = (p, body) => api(`/requests/${id}/${p}`, { method: 'POST', body });
    if (act === 'bid') { await post('bids', { price: +$('#bp').value, warranty_days: +$('#bw').value, eta_minutes: +$('#be').value || undefined, note: $('#bn').value || undefined }); toast('تم إرسال عرضك'); }
    else if (act === 'close') { if (!confirm('إرساء الطلب الآن على أقل سعر؟')) return; await post('close'); }
    else if (act === 'accept') await post('accept');
    else if (act === 'cancel') { if (!confirm('هل تريد إلغاء الطلب؟')) return; await post('cancel'); }
    else if (act === 'status') await post('status', { status: b.dataset.s });
    else if (act === 'review') { if (!stars) throw new Error('اختر عدد النجوم'); await post('review', { stars, tags: [...tags], comment: $('#rc').value || undefined }); toast('شكراً لتقييمك'); }
    else if (act === 'complain') { const text = prompt('اكتب تفاصيل الشكوى'); if (!text) return; await post('complaint', { text }); toast('تم استلام شكواك وستراجعها الإدارة'); return; }
    route(true);
  });
}

/* ---------- الفنيون القريبون ---------- */
let leafletP;
const loadLeaflet = () => leafletP ||= new Promise((res, rej) => {
  if (window.L) return res(window.L);
  const s = document.createElement('script'); s.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js'; s.onload = () => res(window.L); s.onerror = rej; document.head.append(s);
});
async function nearby() {
  view.innerHTML = `<h1>🗺️ الفنيون القريبون الآن</h1><p class="mute">خلال ١٠ كم من موقعك · اطلب أحدهم مباشرة بدون مزاد</p>
    <div class="chips" id="cf" style="margin-bottom:10px"><span class="chip on" data-c="">الكل</span>${S.cfg.categories.map((c) => `<span class="chip" data-c="${c.id}">${c.icon} ${esc(c.name)}</span>`).join('')}</div>
    <div id="map"></div><div id="list"></div>`;
  let pos; try { pos = await geo(); } catch (e) { toast(e.message, true); const z = S.cfg.zones.find((x) => x.id === 'riyadh'); pos = { lat: z.lat, lng: z.lng }; }
  let L = null, map = null, layer = null;
  try { L = await loadLeaflet(); map = L.map('map').setView([pos.lat, pos.lng], 13); L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', { attribution: '© OpenStreetMap' }).addTo(map); layer = L.layerGroup().addTo(map); L.circleMarker([pos.lat, pos.lng], { radius: 9, color: '#fff', weight: 3, fillColor: '#1a73e8', fillOpacity: 1 }).addTo(map); cleanup.push(() => map.remove()); }
  catch { $('#map').remove(); }
  const load = guard(async (cat = '') => {
    if (!S.token) { $('#list').innerHTML = '<div class="empty"><a class="btn" href="#/login">سجّل الدخول لعرض الفنيين</a></div>'; return; }
    const { technicians } = await api(`/nearby?lat=${pos.lat}&lng=${pos.lng}&km=10${cat ? '&category=' + cat : ''}`);
    layer?.clearLayers();
    technicians.forEach((t) => L && L.marker([t.lat, t.lng]).addTo(layer).bindPopup(esc(t.name)));
    $('#list').innerHTML = `<p class="mute">${technicians.length} فني متصل داخل ١٠ كم</p>` + (technicians.map((t) => `<div class="card row"><div class="avatar">${initial(t.name)}</div><div><a href="#/t/${t.id}"><b>${esc(t.name)}</b></a><div class="mute">📍 ${t.distance_km} كم · ${t.rating ? '★ ' + t.rating : 'جديد'} · <span style="color:var(--green)">● متصل الآن</span></div></div><span class="sp"></span>
      ${S.user?.role === 'customer' ? `<a class="btn dark sm" href="#/new/${t.categories[0]}" data-direct="${t.id}" data-cat="${t.categories[0]}">اطلب مباشرة</a>` : ''}</div>`).join('') || '<div class="empty"><div class="ic">🔍</div>لا يوجد فنيون متصلون حالياً</div>');
  });
  $('#cf').onclick = (e) => { const c = e.target.closest('.chip'); if (!c) return; $('#cf').querySelectorAll('.chip').forEach((x) => x.classList.toggle('on', x === c)); load(c.dataset.c); };
  $('#list').onclick = (e) => { const a = e.target.closest('[data-direct]'); if (a) sessionStorage.setItem('direct_' + a.dataset.cat, a.dataset.direct); };
  load();
}

async function techPage(id) {
  if (needLogin()) return;
  const t = await api('/technicians/' + id);
  view.innerHTML = `<a href="javascript:history.back()" class="mute">→ رجوع</a><div class="card" style="text-align:center"><div class="avatar" style="margin:auto;width:84px;height:84px;font-size:32px">${initial(t.name)}</div>
    <h1>${esc(t.name)} <span title="موثّق">✅</span></h1><div class="chips" style="justify-content:center">${t.categories.map((c) => `<span class="tag">${c.icon} ${esc(c.name)}</span>`).join('')}</div>
    <p>★ <b>${t.rating ?? '—'}</b> · ${t.rating_count} تقييم · ${t.jobs_done} عمل مكتمل</p><p class="mute">${t.experience_years} سنة خبرة${t.hourly_rate ? ` · ${t.hourly_rate} ر.س/ساعة` : ''}</p>${t.bio ? `<p>${esc(t.bio)}</p>` : ''}</div>
    <h2>تقييمات العملاء</h2>${t.reviews.map((r) => `<div class="card"><span class="stars">${'★'.repeat(r.stars)}</span> ${r.tags.map((x) => `<span class="tag gold">${esc(x)}</span>`).join(' ')}<p>${esc(r.comment || '')}</p></div>`).join('') || '<div class="empty">لا تقييمات بعد</div>'}`;
}

/* ---------- الفني ---------- */
async function techHome() {
  if (needLogin()) return;
  if (S.user.role !== 'technician') return (location.hash = '#/');
  await refreshMe();
  const t = S.user.tech;
  if (!t.has_id) return (location.hash = '#/tech/setup');
  const tab = sessionStorage.getItem('ttab') || 'feed';
  const banner = t.status === 'pending' ? '<div class="card gold">⏳ حسابك قيد مراجعة الإدارة. يمكنك استعراض الطلبات، وتقديم العروض بعد الاعتماد.</div>'
    : t.status === 'rejected' ? `<div class="card" style="border-color:var(--red)">❌ تم رفض التوثيق: ${esc(t.reject_reason || '')} — <a href="#/tech/setup">عدّل بياناتك</a></div>` : '';
  const { requests } = await api('/requests?scope=' + tab);
  view.innerHTML = `${banner}<div class="card row"><div><b>${t.online ? '🟢 متصل — تظهر للعملاء القريبين' : '⚪ غير متصل'}</b><div class="mute">★ ${t.rating ?? '—'} · ${t.jobs_done} عمل · محفظة ${money(t.wallet_balance)}</div></div><span class="sp"></span><button class="btn sm ${t.online ? 'ghost' : ''}" id="on">${t.online ? 'إيقاف' : 'تفعيل الاتصال'}</button></div>
    <div class="tabs" id="tabs">${[['feed', 'الطلبات المتاحة'], ['bids', 'عروضي'], ['jobs', 'أعمالي']].map(([k, l]) => `<button data-k="${k}" class="${tab === k ? 'on' : ''}">${l}</button>`).join('')}</div>
    ${requests.map(reqCard).join('') || '<div class="empty"><div class="ic">📭</div><p>لا توجد طلبات حالياً في منطقتك وتخصصك</p></div>'}`;
  $('#tabs').onclick = (e) => { const b = e.target.closest('button'); if (b) { sessionStorage.setItem('ttab', b.dataset.k); route(true); } };
  $('#on').onclick = guard(async () => {
    let pos = {}; if (!t.online) { try { pos = await geo(); } catch { toast('تعذر تحديد موقعك — سيُستخدم آخر موقع محفوظ', true); } }
    await api('/tech/status', { method: 'POST', body: { online: !t.online, ...pos } }); route(true);
  });
}
async function techSetup() {
  if (needLogin()) return;
  if (S.user.role !== 'technician') return (location.hash = '#/');
  await refreshMe();
  const t = S.user.tech, cats = new Set(t.categories), zones = new Set(t.zones); let idPhoto = null;
  view.innerHTML = `<h1>بيانات الفني والتوثيق</h1><div class="card"><label class="field"><span>رقم الهوية / الإقامة</span><input id="idn" inputmode="numeric" maxlength="10" dir="ltr"></label>
    <div class="field"><span>صورة الهوية / الإقامة ${t.has_id ? '(اختياري للتحديث)' : ''}</span><input type="file" id="idp" accept="image/*"><div class="mute" id="idst"></div></div>
    <div class="field"><span>تخصصاتك</span><div class="chips" id="cc">${S.cfg.categories.map((c) => `<span class="chip ${cats.has(c.id) ? 'on' : ''}" data-id="${c.id}">${c.icon} ${esc(c.name)}</span>`).join('')}</div></div>
    <div class="field"><span>المناطق التي تخدمها (تصلك طلباتها)</span><div class="chips" id="zz">${S.cfg.zones.map((z) => `<span class="chip ${zones.has(z.id) ? 'on' : ''}" data-id="${z.id}">${esc(z.name)}</span>`).join('')}</div></div>
    <div class="row"><label class="field sp"><span>سنوات الخبرة</span><input id="ye" type="number" min="0" max="60" value="${t.experience_years || 0}"></label><label class="field sp"><span>سعر الساعة (اختياري)</span><input id="hr" type="number" min="1" value="${t.hourly_rate || ''}"></label></div>
    <label class="field"><span>نبذة عنك</span><textarea id="bio" maxlength="500">${esc(t.bio || '')}</textarea></label>
    <button class="btn block" id="sv">حفظ وإرسال للمراجعة</button><p class="mute">بيانات الهوية تُحفظ بشكل خاص ولا تظهر للعملاء. تُراجع خلال ساعات عمل الإدارة.</p></div>`;
  for (const id of ['cc', 'zz']) $('#' + id).onclick = (e) => { const c = e.target.closest('.chip'); if (!c) return; const set = id === 'cc' ? cats : zones; c.classList.toggle('on'); set.has(c.dataset.id) ? set.delete(c.dataset.id) : set.add(c.dataset.id); };
  $('#idp').onchange = guard(async (e) => { if (!e.target.files[0]) return; $('#idst').textContent = 'جارٍ الرفع…'; idPhoto = await upload(e.target.files[0], 'id'); $('#idst').textContent = '✅ تم رفع الصورة'; });
  $('#sv').onclick = guard(async () => {
    if (!t.has_id && !idPhoto) throw new Error('ارفع صورة الهوية / الإقامة');
    await api('/tech/profile', { method: 'POST', body: { id_number: $('#idn').value, id_photo: idPhoto || undefined, categories: [...cats], zones: [...zones], experience_years: +$('#ye').value, hourly_rate: +$('#hr').value || undefined, bio: $('#bio').value } });
    toast('تم الحفظ وإرسال بياناتك للمراجعة'); location.hash = '#/tech';
  });
}
async function wallet() {
  if (needLogin()) return;
  if (S.user.role !== 'technician') return (location.hash = '#/');
  const w = await api('/wallet');
  const kinds = { commission: 'عمولة المنصة', topup: 'شحن رصيد', adjustment: 'تسوية' };
  view.innerHTML = `<h1>المحفظة</h1><div class="wallet"><div style="opacity:.8">الرصيد الحالي</div><div class="big" style="font-size:42px" dir="ltr">${nf.format(w.balance)} <small style="font-size:18px">ر.س</small></div><p style="opacity:.8;margin-bottom:0">عمولة المنصة ${w.commission_pct}% من قيمة كل عمل مكتمل · يتوقف تقديم العروض عند رصيد أقل من −${w.max_debt} ر.س</p></div>
    <h2>الحركات</h2>${w.transactions.map((t) => `<div class="card row"><div><b>${kinds[t.kind] || t.kind}</b><div class="mute">${new Date(t.created_at).toLocaleString('ar-SA')} ${esc(t.note || '')}</div></div><span class="sp"></span><span class="price" style="color:${t.amount < 0 ? 'var(--red)' : 'var(--ok)'}" dir="ltr">${t.amount > 0 ? '+' : ''}${nf.format(t.amount)}</span></div>`).join('') || '<div class="empty">لا حركات بعد</div>'}
    <p class="mute">لشحن المحفظة تواصل مع الدعم: mhnty011@gmail.com</p>`;
}

/* ---------- الحساب ---------- */
async function profile() {
  if (needLogin()) return;
  await refreshMe();
  const u = S.user;
  view.innerHTML = `<div class="card" style="text-align:center"><div class="avatar" style="margin:auto;width:84px;height:84px;font-size:32px">${initial(u.name)}</div><h1>${esc(u.name)}</h1>
    <span class="tag">${{ customer: 'عميل', technician: 'فني', admin: 'مدير' }[u.role]}</span><p class="mute" dir="ltr">${esc(u.phone)}</p></div>
    ${u.role === 'customer' ? `<div class="wallet"><div>👑 نادي الولاء</div><div class="big">${nf.format(u.points)} <small>نقطة</small></div><p style="opacity:.85;margin-bottom:0">تكسب نقاطاً عن كل طلب مكتمل</p></div><br>` : ''}
    <div class="card"><label class="field"><span>الاسم</span><input id="nm" value="${esc(u.name)}" maxlength="60"></label><button class="btn block" id="sv">حفظ</button></div>
    ${u.role === 'technician' ? '<a class="btn ghost block" href="#/tech/setup" style="margin-bottom:10px">تعديل بيانات الفني</a>' : ''}
    <div class="card"><a href="/privacy">سياسة الخصوصية</a> · <a href="/terms">الشروط والأحكام</a><p class="mute">الدعم: mhnty011@gmail.com</p></div>
    <button class="btn danger block" id="lo">تسجيل الخروج</button><p style="text-align:center"><a href="#" id="del" class="mute">حذف حسابي</a></p>`;
  $('#sv').onclick = guard(async () => { S.user = await api('/me', { method: 'PATCH', body: { name: $('#nm').value } }); toast('تم الحفظ'); });
  $('#lo').onclick = () => logout();
  $('#del').onclick = guard(async (e) => { e.preventDefault(); if (!confirm('سيتم حذف حسابك نهائياً. متأكد؟')) return; await api('/me', { method: 'DELETE' }); logout(); });
}

/* ---------- الإدارة ---------- */
async function admin() {
  if (needLogin()) return;
  if (S.user.role !== 'admin') return (location.hash = '#/');
  const [st, pend, comp] = await Promise.all([api('/admin/stats'), api('/admin/technicians?status=pending'), api('/admin/complaints')]);
  const blob = async (url) => { const r = await fetch(url, { headers: { authorization: 'Bearer ' + S.token } }); return URL.createObjectURL(await r.blob()); };
  view.innerHTML = `<h1>لوحة الإدارة</h1><div class="grid-cat" style="grid-template-columns:repeat(auto-fit,minmax(150px,1fr))">${[['العملاء', st.users], ['الفنيون المعتمدون', st.technicians], ['بانتظار الاعتماد', st.pending_technicians], ['الطلبات', st.requests], ['مفتوحة', st.open_requests], ['مكتملة', st.completed], ['شكاوى مفتوحة', st.open_complaints], ['العمولات (ر.س)', st.revenue]].map(([l, v]) => `<div class="card"><div class="mute">${l}</div><div class="big">${nf.format(v)}</div></div>`).join('')}</div>
    <h2>فنيون بانتظار الاعتماد</h2>${pend.technicians.map((t) => `<div class="card"><b>${esc(t.name)}</b> <span class="mute" dir="ltr">${esc(t.phone)}</span><p class="mute">هوية: <span dir="ltr">${esc(t.id_number)}</span> · خبرة ${t.experience_years} سنة</p><p>${esc(t.bio || '')}</p>
      ${t.id_photo ? `<img data-src="${esc(t.id_photo)}" alt="الهوية" style="max-width:260px;border-radius:12px;border:1px solid var(--line)">` : '<span class="tag red">بدون صورة هوية</span>'}
      <div class="row" style="margin-top:10px"><button class="btn sm" data-ap="${t.id}">اعتماد</button><button class="btn danger sm" data-rj="${t.id}">رفض</button></div></div>`).join('') || '<div class="empty">لا طلبات اعتماد</div>'}
    <h2>الشكاوى</h2>${comp.complaints.map((c) => `<div class="card"><span class="tag ${c.status === 'open' ? 'red' : ''}">${c.status === 'open' ? 'مفتوحة' : 'محلولة'}</span> <b>${esc(c.user_name)}</b> ضد <b>${esc(c.against_name || '—')}</b><p>${esc(c.text)}</p>${c.resolution ? `<p class="mute">القرار: ${esc(c.resolution)}</p>` : `<button class="btn sm" data-rs="${c.id}">إغلاق بقرار</button>`}</div>`).join('') || '<div class="empty">لا شكاوى</div>'}
    <h2>شحن محفظة فني</h2><div class="card"><label class="field"><span>معرّف الفني (id)</span><input id="wt" dir="ltr"></label><div class="row"><label class="field sp"><span>المبلغ (+ شحن / − خصم)</span><input id="wa" type="number"></label><label class="field sp"><span>ملاحظة</span><input id="wn"></label></div><button class="btn" id="wg">تنفيذ</button></div>`;
  view.querySelectorAll('img[data-src]').forEach(async (i) => (i.src = await blob(i.dataset.src)));
  view.onclick = guard(async (e) => {
    const b = e.target.closest('button'); if (!b) return;
    if (b.dataset.ap) await api(`/admin/technicians/${b.dataset.ap}/review`, { method: 'POST', body: { approve: true } });
    else if (b.dataset.rj) { const reason = prompt('سبب الرفض'); if (!reason) return; await api(`/admin/technicians/${b.dataset.rj}/review`, { method: 'POST', body: { approve: false, reason } }); }
    else if (b.dataset.rs) { const resolution = prompt('قرار الإدارة'); if (!resolution) return; await api(`/admin/complaints/${b.dataset.rs}/resolve`, { method: 'POST', body: { resolution } }); }
    else if (b.id === 'wg') { await api('/admin/wallet', { method: 'POST', body: { tech_id: $('#wt').value.trim(), amount: +$('#wa').value, note: $('#wn').value || undefined } }); toast('تم'); }
    else return;
    route(true);
  });
}

$('#bell').onclick = guard(async () => {
  const { notifications } = await api('/notifications'); await api('/notifications/read', { method: 'POST' });
  $('#bell .dot').hidden = true;
  view.insertAdjacentHTML('afterbegin', `<div class="card"><b>الإشعارات</b>${notifications.map((n) => `<div class="mute">• ${esc((NOTIF[n.type] || (() => n.type))(n.payload))}</div>`).join('') || '<div class="mute">لا إشعارات</div>'}</div>`);
});

boot();
