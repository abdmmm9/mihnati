import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

/// عنوان الخادم: flutter run --dart-define=API_BASE=https://your-domain.com
const apiBase = String.fromEnvironment('API_BASE', defaultValue: 'http://10.0.2.2:3000');

class ApiError implements Exception {
  final String message;
  ApiError(this.message);
  @override
  String toString() => message;
}

class Api {
  static String? token;
  static Map<String, dynamic>? user;
  static Map<String, dynamic> config = {};

  static Future<void> init() async {
    final p = await SharedPreferences.getInstance();
    token = p.getString('token');
    config = await get('/config');
    if (token != null) {
      try {
        user = await get('/me');
      } catch (_) {
        await logout();
      }
    }
  }

  static Future<void> setSession(String t, Map<String, dynamic> u) async {
    token = t;
    user = u;
    (await SharedPreferences.getInstance()).setString('token', t);
  }

  static Future<void> logout() async {
    token = null;
    user = null;
    (await SharedPreferences.getInstance()).remove('token');
  }

  static Map<String, String> get _headers => {
        'content-type': 'application/json',
        if (token != null) 'authorization': 'Bearer $token',
      };

  static Future<Map<String, dynamic>> _handle(http.Response r) async {
    Map<String, dynamic> body = {};
    try {
      body = jsonDecode(utf8.decode(r.bodyBytes)) as Map<String, dynamic>;
    } catch (_) {}
    if (r.statusCode == 401 && token != null) await logout();
    if (r.statusCode >= 400) throw ApiError((body['error'] ?? 'تعذر تنفيذ الطلب') as String);
    return body;
  }

  static Future<Map<String, dynamic>> get(String path) async =>
      _handle(await http.get(Uri.parse('$apiBase/api$path'), headers: _headers).timeout(const Duration(seconds: 20)));

  static Future<Map<String, dynamic>> post(String path, [Map<String, dynamic>? body, String method = 'POST']) async {
    final req = http.Request(method, Uri.parse('$apiBase/api$path'))
      ..headers.addAll(_headers)
      ..body = jsonEncode(body ?? {});
    return _handle(await http.Response.fromStream(await req.send().timeout(const Duration(seconds: 30))));
  }

  static Future<Map<String, dynamic>> refreshMe() async => user = await get('/me');

  /// رفع صورة (base64). kind='id' لصورة الهوية الخاصة.
  static Future<String> upload(List<int> bytes, {String kind = 'public'}) async {
    final r = await post('/uploads', {'data': base64Encode(bytes), 'kind': kind});
    return r['url'] as String;
  }
}

String money(num n) => '$n ر.س';

String firstChar(String s) => s.isEmpty ? '؟' : String.fromCharCode(s.runes.first);
