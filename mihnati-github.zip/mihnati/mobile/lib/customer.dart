import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:image_picker/image_picker.dart';
import 'api.dart';
import 'request.dart';

class CustomerShell extends StatefulWidget {
  final VoidCallback onLogout;
  const CustomerShell({super.key, required this.onLogout});
  @override
  State<CustomerShell> createState() => _CustomerShellState();
}

class _CustomerShellState extends State<CustomerShell> {
  int tab = 0;
  @override
  Widget build(BuildContext context) {
    final pages = [const CategoriesPage(), const MyRequestsPage(), const NearbyPage(), ProfilePage(onLogout: widget.onLogout)];
    return Scaffold(
      appBar: AppBar(title: const Text('مهنتي')),
      body: pages[tab],
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.receipt_long_outlined), label: 'طلباتي'),
          NavigationDestination(icon: Icon(Icons.map_outlined), label: 'القريبون'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'حسابي'),
        ],
      ),
    );
  }
}

class CategoriesPage extends StatelessWidget {
  const CategoriesPage({super.key});
  @override
  Widget build(BuildContext context) {
    final cats = ((Api.config['categories'] ?? []) as List).cast<Map<String, dynamic>>();
    return ListView(padding: const EdgeInsets.all(16), children: [
      Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF006C35), Color(0xFF004D26)]), borderRadius: BorderRadius.circular(24)),
        child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('ابحث عن حرفي موثوق', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
          SizedBox(height: 4),
          Text('انشر طلبك والفنيون يتنافسون، والأقل سعراً يفوز', style: TextStyle(color: Colors.white70)),
        ]),
      ),
      const SizedBox(height: 16),
      GridView.count(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        crossAxisCount: MediaQuery.of(context).size.width > 700 ? 4 : 2,
        mainAxisSpacing: 12,
        crossAxisSpacing: 12,
        childAspectRatio: 1.05,
        children: [
          for (final c in cats)
            InkWell(
              borderRadius: BorderRadius.circular(22),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => NewRequestScreen(category: c))),
              child: Card(
                color: const Color(0xFFFFFDF8),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22), side: const BorderSide(color: Color(0xFFE8D48B), width: 2)),
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Text('${c['icon']}', style: const TextStyle(fontSize: 40)),
                  const SizedBox(height: 6),
                  Text('${c['name']}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const Text('اطلب الآن ←', style: TextStyle(color: Color(0xFF006C35))),
                ]),
              ),
            ),
        ],
      ),
    ]);
  }
}

Future<Position> currentPosition() async {
  if (!await Geolocator.isLocationServiceEnabled()) throw ApiError('فعّل خدمة الموقع في جهازك');
  var p = await Geolocator.checkPermission();
  if (p == LocationPermission.denied) p = await Geolocator.requestPermission();
  if (p == LocationPermission.denied || p == LocationPermission.deniedForever) throw ApiError('لم يُمنح إذن الموقع، اختر مدينتك يدوياً');
  return Geolocator.getCurrentPosition(locationSettings: const LocationSettings(accuracy: LocationAccuracy.high, timeLimit: Duration(seconds: 12)));
}

class NewRequestScreen extends StatefulWidget {
  final Map<String, dynamic> category;
  final String? directTechId;
  const NewRequestScreen({super.key, required this.category, this.directTechId});
  @override
  State<NewRequestScreen> createState() => _NewRequestScreenState();
}

class _NewRequestScreenState extends State<NewRequestScreen> {
  final title = TextEditingController(), desc = TextEditingController(), addr = TextEditingController();
  double? lat, lng;
  String? zone;
  int minutes = 60;
  final photos = <String>[];
  bool busy = false;

  void _msg(Object e) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));

  @override
  Widget build(BuildContext context) {
    final zones = ((Api.config['zones'] ?? []) as List).cast<Map<String, dynamic>>();
    final durations = ((Api.config['durations'] ?? [15, 30, 60, 180, 1440]) as List).cast<int>();
    return Scaffold(
      appBar: AppBar(title: Text('طلب ${widget.category['name']}')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        if (widget.directTechId != null) const Card(child: Padding(padding: EdgeInsets.all(12), child: Text('طلب مباشر لفني محدد (بدون مزاد)'))),
        TextField(controller: title, maxLength: 80, decoration: const InputDecoration(labelText: 'عنوان مختصر')),
        const SizedBox(height: 8),
        TextField(controller: desc, maxLines: 4, maxLength: 1000, decoration: const InputDecoration(labelText: 'وصف المشكلة')),
        const SizedBox(height: 8),
        Wrap(spacing: 8, children: [
          for (final p in photos) const Icon(Icons.image, size: 40),
          if (photos.length < 5)
            OutlinedButton.icon(
              icon: const Icon(Icons.photo_camera),
              label: const Text('إضافة صورة'),
              onPressed: () async {
                try {
                  final f = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 1280, imageQuality: 82);
                  if (f == null) return;
                  final url = await Api.upload(await f.readAsBytes());
                  setState(() => photos.add(url));
                } catch (e) {
                  _msg(e);
                }
              },
            ),
        ]),
        const SizedBox(height: 12),
        Row(children: [
          OutlinedButton.icon(
            icon: const Icon(Icons.my_location),
            label: Text(lat == null ? 'استخدم موقعي' : '✅ تم تحديد موقعك'),
            onPressed: () async {
              try {
                final p = await currentPosition();
                setState(() { lat = p.latitude; lng = p.longitude; zone = null; });
              } catch (e) {
                _msg(e);
              }
            },
          ),
        ]),
        const SizedBox(height: 8),
        DropdownButtonFormField<String>(
          value: zone,
          decoration: const InputDecoration(labelText: 'أو اختر مدينتك'),
          items: [for (final z in zones) DropdownMenuItem(value: z['id'] as String, child: Text('${z['name']}'))],
          onChanged: (v) => setState(() {
            zone = v;
            if (v != null) {
              final z = zones.firstWhere((x) => x['id'] == v);
              lat = (z['lat'] as num).toDouble();
              lng = (z['lng'] as num).toDouble();
            }
          }),
        ),
        const SizedBox(height: 8),
        TextField(controller: addr, decoration: const InputDecoration(labelText: 'وصف العنوان (حي/شارع/معلم)')),
        if (widget.directTechId == null) ...[
          const SizedBox(height: 8),
          DropdownButtonFormField<int>(
            value: minutes,
            decoration: const InputDecoration(labelText: 'مدة استقبال العروض'),
            items: [for (final m in durations) DropdownMenuItem(value: m, child: Text(m < 60 ? '$m دقيقة' : m == 1440 ? 'يوم كامل' : '${m ~/ 60} ساعة'))],
            onChanged: (v) => setState(() => minutes = v ?? 60),
          ),
        ],
        const SizedBox(height: 16),
        FilledButton(
          onPressed: busy
              ? null
              : () async {
                  if (lat == null) return _msg('حدد موقعك أو اختر مدينتك');
                  setState(() => busy = true);
                  try {
                    final r = await Api.post('/requests', {
                      'category_id': widget.category['id'],
                      if (title.text.isNotEmpty) 'title': title.text,
                      'description': desc.text,
                      'photos': photos,
                      'lat': lat,
                      'lng': lng,
                      if (zone != null) 'zone_id': zone,
                      if (addr.text.isNotEmpty) 'address': addr.text,
                      'duration_minutes': minutes,
                      if (widget.directTechId != null) 'direct_tech_id': widget.directTechId,
                    });
                    if (!mounted) return;
                    Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => RequestScreen(id: r['id'] as String)));
                  } catch (e) {
                    _msg(e);
                  } finally {
                    if (mounted) setState(() => busy = false);
                  }
                },
          child: Text(widget.directTechId != null ? 'إرسال للفني' : 'نشر الطلب'),
        ),
      ]),
    );
  }
}

class MyRequestsPage extends StatefulWidget {
  const MyRequestsPage({super.key});
  @override
  State<MyRequestsPage> createState() => _MyRequestsPageState();
}

class _MyRequestsPageState extends State<MyRequestsPage> {
  late Future<Map<String, dynamic>> f = Api.get('/requests');
  @override
  Widget build(BuildContext context) => RefreshIndicator(
        onRefresh: () async { setState(() => f = Api.get('/requests')); await f; },
        child: FutureBuilder<Map<String, dynamic>>(
          future: f,
          builder: (c, s) {
            if (s.hasError) return Center(child: Text('${s.error}'));
            if (!s.hasData) return const Center(child: CircularProgressIndicator());
            final list = (s.data!['requests'] as List).cast<Map<String, dynamic>>();
            if (list.isEmpty) return ListView(children: const [SizedBox(height: 120), Center(child: Text('لا توجد طلبات بعد'))]);
            return ListView(
              padding: const EdgeInsets.all(12),
              children: [for (final r in list) RequestTile(r: r, onTap: () async { await Navigator.push(c, MaterialPageRoute(builder: (_) => RequestScreen(id: r['id']))); setState(() => f = Api.get('/requests')); })],
            );
          },
        ),
      );
}

class NearbyPage extends StatefulWidget {
  const NearbyPage({super.key});
  @override
  State<NearbyPage> createState() => _NearbyPageState();
}

class _NearbyPageState extends State<NearbyPage> {
  Future<List<Map<String, dynamic>>>? f;
  @override
  void initState() {
    super.initState();
    f = _load();
  }

  Future<List<Map<String, dynamic>>> _load() async {
    final p = await currentPosition();
    final r = await Api.get('/nearby?lat=${p.latitude}&lng=${p.longitude}&km=10');
    return (r['technicians'] as List).cast<Map<String, dynamic>>();
  }

  @override
  Widget build(BuildContext context) => FutureBuilder<List<Map<String, dynamic>>>(
        future: f,
        builder: (c, s) {
          if (s.hasError) return Center(child: Padding(padding: const EdgeInsets.all(24), child: Text('${s.error}', textAlign: TextAlign.center)));
          if (!s.hasData) return const Center(child: CircularProgressIndicator());
          final cats = {for (final x in ((Api.config['categories'] ?? []) as List).cast<Map<String, dynamic>>()) x['id']: x};
          return ListView(padding: const EdgeInsets.all(12), children: [
            const Text('🗺️ الفنيون القريبون الآن (خلال ١٠ كم)', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            if (s.data!.isEmpty) const Padding(padding: EdgeInsets.all(32), child: Center(child: Text('لا يوجد فنيون متصلون حالياً'))),
            for (final t in s.data!)
              Card(
                child: ListTile(
                  leading: CircleAvatar(child: Text('${firstChar(t['name'] as String)}')),
                  title: Text('${t['name']}'),
                  subtitle: Text('📍 ${t['distance_km']} كم · ${t['rating'] != null ? '★ ${t['rating']}' : 'جديد'} · متصل الآن'),
                  trailing: FilledButton(
                    style: FilledButton.styleFrom(minimumSize: const Size(100, 38)),
                    onPressed: () => Navigator.push(c, MaterialPageRoute(builder: (_) => NewRequestScreen(category: cats[(t['categories'] as List).first]!, directTechId: t['id']))),
                    child: const Text('اطلب مباشرة'),
                  ),
                ),
              ),
          ]);
        },
      );
}

class ProfilePage extends StatelessWidget {
  final VoidCallback onLogout;
  const ProfilePage({super.key, required this.onLogout});
  @override
  Widget build(BuildContext context) {
    final u = Api.user!;
    return ListView(padding: const EdgeInsets.all(16), children: [
      Card(child: Padding(padding: const EdgeInsets.all(20), child: Column(children: [
        CircleAvatar(radius: 38, backgroundColor: const Color(0xFF006C35), child: Text(firstChar(u['name'] as String), style: const TextStyle(fontSize: 30, color: Colors.white))),
        const SizedBox(height: 8),
        Text('${u['name']}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        Text('${u['phone']}', textDirection: TextDirection.ltr),
      ]))),
      if (u['role'] == 'customer')
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(color: const Color(0xFF5A0D25), borderRadius: BorderRadius.circular(20)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('👑 نادي الولاء', style: TextStyle(color: Colors.white)),
            Text('${u['points']} نقطة', style: const TextStyle(color: Colors.white, fontSize: 30, fontWeight: FontWeight.bold)),
            const Text('تكسب نقاطاً عن كل طلب مكتمل', style: TextStyle(color: Colors.white70)),
          ]),
        ),
      const SizedBox(height: 12),
      OutlinedButton(onPressed: () async { await Api.logout(); onLogout(); }, child: const Text('تسجيل الخروج')),
      TextButton(
        style: TextButton.styleFrom(foregroundColor: Colors.red),
        onPressed: () async {
          final ok = await showDialog<bool>(
            context: context,
            builder: (x) => AlertDialog(content: const Text('سيتم حذف حسابك نهائياً. متأكد؟'), actions: [
              TextButton(onPressed: () => Navigator.pop(x, false), child: const Text('إلغاء')),
              TextButton(onPressed: () => Navigator.pop(x, true), child: const Text('حذف')),
            ]),
          );
          if (ok != true) return;
          try {
            await Api.post('/me', null, 'DELETE');
            await Api.logout();
            onLogout();
          } catch (e) {
            if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
          }
        },
        child: const Text('حذف حسابي'),
      ),
    ]);
  }
}
