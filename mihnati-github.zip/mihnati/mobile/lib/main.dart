import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'api.dart';
import 'auth.dart';
import 'customer.dart';
import 'technician.dart';

const green = Color(0xFF006C35);
const gold = Color(0xFFC9A227);
const cream = Color(0xFFFBF7EC);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  Object? err;
  try {
    await Api.init();
  } catch (e) {
    err = e;
  }
  runApp(MihnatiApp(startError: err));
}

class MihnatiApp extends StatelessWidget {
  final Object? startError;
  const MihnatiApp({super.key, this.startError});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'مهنتي',
      debugShowCheckedModeBanner: false,
      locale: const Locale('ar', 'SA'),
      supportedLocales: const [Locale('ar', 'SA')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: green, primary: green, secondary: gold),
        scaffoldBackgroundColor: const Color(0xFFF6F8FA),
        appBarTheme: const AppBarTheme(backgroundColor: green, foregroundColor: Colors.white, centerTitle: true),
        cardTheme: CardThemeData(
          color: Colors.white,
          elevation: 0,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18), side: const BorderSide(color: Color(0xFFE9E1C6))),
        ),
        filledButtonTheme: FilledButtonThemeData(
          style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(50), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
        ),
        inputDecorationTheme: InputDecorationTheme(border: OutlineInputBorder(borderRadius: BorderRadius.circular(12))),
      ),
      home: startError != null ? _Retry(error: startError!) : const Root(),
    );
  }
}

class _Retry extends StatelessWidget {
  final Object error;
  const _Retry({required this.error});
  @override
  Widget build(BuildContext context) => Scaffold(
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              const Icon(Icons.wifi_off, size: 48),
              const SizedBox(height: 12),
              Text('تعذر الاتصال بالخادم\n$error', textAlign: TextAlign.center),
              const SizedBox(height: 16),
              FilledButton(
                onPressed: () async {
                  Object? e;
                  try {
                    await Api.init();
                  } catch (x) {
                    e = x;
                  }
                  if (context.mounted) {
                    Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => e == null ? const Root() : _Retry(error: e!)));
                  }
                },
                child: const Text('إعادة المحاولة'),
              ),
            ]),
          ),
        ),
      );
}

/// يوجّه حسب الدور: ضيف → دخول، عميل، فني، مدير (الإدارة عبر الموقع)
class Root extends StatefulWidget {
  const Root({super.key});
  @override
  State<Root> createState() => _RootState();
}

class _RootState extends State<Root> {
  void _refresh() => setState(() {});

  @override
  Widget build(BuildContext context) {
    final u = Api.user;
    if (u == null) return LoginScreen(onDone: _refresh, onGuest: _refresh);
    switch (u['role']) {
      case 'technician':
        return TechShell(onLogout: _refresh);
      case 'admin':
        return Scaffold(
          appBar: AppBar(title: const Text('مهنتي')),
          body: Center(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              const Text('لوحة الإدارة متاحة عبر الموقع'),
              const SizedBox(height: 12),
              FilledButton(onPressed: () async { await Api.logout(); _refresh(); }, child: const Text('تسجيل الخروج')),
            ]),
          ),
        );
      default:
        return CustomerShell(onLogout: _refresh);
    }
  }
}
