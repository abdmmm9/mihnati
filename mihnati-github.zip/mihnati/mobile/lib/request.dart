import 'dart:async';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'api.dart';

const statusLabels = {
  'open': 'مفتوح للعروض',
  'awarded': 'تم الإرساء',
  'on_the_way': 'الفني في الطريق',
  'arrived': 'وصل الفني',
  'in_progress': 'جارٍ العمل',
  'completed': 'مكتمل',
  'cancelled': 'ملغي',
  'expired': 'انتهى بدون عروض',
};
const nextStatus = {
  'awarded': ['on_the_way', 'أنا في الطريق'],
  'on_the_way': ['arrived', 'وصلت إلى الموقع'],
  'arrived': ['in_progress', 'بدء العمل'],
  'in_progress': ['completed', 'تم إنهاء العمل'],
};

String fmtLeft(int ms) {
  if (ms <= 0) return 'انتهى الوقت';
  final s = ms ~/ 1000;
  final h = s ~/ 3600, m = (s % 3600) ~/ 60, x = s % 60;
  return '${h > 0 ? '$h:' : ''}${m.toString().padLeft(2, '0')}:${x.toString().padLeft(2, '0')}';
}

/// بطاقة طلب في القوائم
class RequestTile extends StatelessWidget {
  final Map<String, dynamic> r;
  final VoidCallback onTap;
  const RequestTile({super.key, required this.r, required this.onTap});
  @override
  Widget build(BuildContext context) {
    final low = r['final_price'] ?? r['lowest_price'];
    return Card(
      child: ListTile(
        onTap: onTap,
        leading: Text('${r['category_icon']}', style: const TextStyle(fontSize: 28)),
        title: Text('${r['title']}', style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text('${r['category_name']} · ${r['zone_name']}\n${r['bids_count']} عرض${low != null ? ' · الأقل ${money(low)}' : ''}'),
        isThreeLine: true,
        trailing: Chip(label: Text(statusLabels[r['status']] ?? '', style: const TextStyle(fontSize: 12))),
      ),
    );
  }
}

class RequestScreen extends StatefulWidget {
  final String id;
  const RequestScreen({super.key, required this.id});
  @override
  State<RequestScreen> createState() => _RequestScreenState();
}

class _RequestScreenState extends State<RequestScreen> {
  Map<String, dynamic>? r;
  String? error;
  Timer? poll, tick;
  int skew = 0;
  int stars = 0;
  final price = TextEditingController(), eta = TextEditingController(), note = TextEditingController(), comment = TextEditingController();
  int warranty = 0;
  final tags = <String>{};

  bool get isTech => Api.user?['role'] == 'technician';

  @override
  void initState() {
    super.initState();
    _load();
    poll = Timer.periodic(const Duration(seconds: 5), (_) => _load());
    tick = Timer.periodic(const Duration(seconds: 1), (_) => mounted ? setState(() {}) : null);
  }

  @override
  void dispose() {
    poll?.cancel();
    tick?.cancel();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final d = await Api.get('/requests/${widget.id}');
      if (!mounted) return;
      setState(() {
        r = d;
        skew = (d['now'] as int) - DateTime.now().millisecondsSinceEpoch;
        error = null;
      });
    } catch (e) {
      if (mounted && r == null) setState(() => error = '$e');
    }
  }

  Future<void> _do(String path, [Map<String, dynamic>? body]) async {
    try {
      final d = await Api.post('/requests/${widget.id}/$path', body);
      if (mounted) setState(() => r = d);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
    }
  }

  Future<bool> _confirm(String msg) async =>
      await showDialog<bool>(
        context: context,
        builder: (c) => AlertDialog(content: Text(msg), actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('لا')),
          TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('نعم')),
        ]),
      ) ??
      false;

  @override
  Widget build(BuildContext context) {
    final d = r;
    return Scaffold(
      appBar: AppBar(title: const Text('تفاصيل الطلب')),
      body: d == null
          ? Center(child: error != null ? Text(error!) : const CircularProgressIndicator())
          : RefreshIndicator(onRefresh: _load, child: _body(d)),
    );
  }

  Widget _body(Map<String, dynamic> d) {
    final status = d['status'] as String;
    final isOwner = d['is_owner'] == true;
    final me = Api.user!['id'];
    final bids = (d['bids'] as List).cast<Map<String, dynamic>>();
    final left = (d['deadline_at'] as int) - (DateTime.now().millisecondsSinceEpoch + skew);
    final mine = d['my_bid'] as Map<String, dynamic>?;

    return ListView(padding: const EdgeInsets.all(16), children: [
      Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Text('${d['category_icon']}', style: const TextStyle(fontSize: 30)),
              const SizedBox(width: 10),
              Expanded(child: Text('${d['title']}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),
              Chip(label: Text(statusLabels[status] ?? '')),
            ]),
            Text('${d['category_name']} · ${d['zone_name']}', style: const TextStyle(color: Colors.black54)),
            const SizedBox(height: 8),
            Text('${d['description']}'),
            if (status == 'open') ...[
              const Divider(height: 24),
              Row(children: [
                const Text('⏱ ينتهي خلال '),
                Text(fmtLeft(left), style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800, color: left < 60000 ? Colors.red : const Color(0xFF006C35))),
                const Spacer(),
                if (d['lowest_price'] != null)
                  Column(children: [
                    const Text('أقل سعر', style: TextStyle(fontSize: 12)),
                    Text(money(d['lowest_price']), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 18, color: Color(0xFF14A44D))),
                  ]),
              ]),
            ],
          ]),
        ),
      ),
      if (d['tech_phone'] != null && isOwner) _contact('الفني: ${d['tech_name']}', d['tech_phone'], 'السعر النهائي ${money(d['final_price'])} · ضمان ${d['warranty_days'] ?? 0} يوم'),
      if (isTech && d['customer_phone'] != null)
        _contact('العميل: ${d['customer_name']}', d['customer_phone'], d['address'] ?? '', geo: 'https://www.google.com/maps?q=${d['lat']},${d['lng']}'),
      if (isTech && d['awarded_tech_id'] == me && nextStatus[status] != null)
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: FilledButton(onPressed: () => _do('status', {'status': nextStatus[status]![0]}), child: Text(nextStatus[status]![1])),
        ),
      if (isTech && status == 'open') _bidForm(d, mine),
      Padding(padding: const EdgeInsets.only(top: 12, bottom: 6), child: Text('العروض (${bids.length})', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),
      if (bids.isEmpty) const Padding(padding: EdgeInsets.all(24), child: Center(child: Text('لا توجد عروض بعد…'))),
      for (final b in bids)
        Card(
          color: b['is_winner'] == true ? const Color(0xFFFBF7EC) : (b['is_lowest'] == true && status == 'open' ? const Color(0xFFF3FBF6) : null),
          shape: b['is_lowest'] == true && status == 'open' ? RoundedRectangleBorder(borderRadius: BorderRadius.circular(18), side: const BorderSide(color: Color(0xFF14A44D), width: 2)) : null,
          child: ListTile(
            leading: CircleAvatar(backgroundColor: const Color(0xFF006C35), child: Text('${firstChar(b['tech_name'] as String)}', style: const TextStyle(color: Colors.white))),
            title: Text('${b['tech_name']}${b['mine'] == true ? ' (عرضي)' : ''}${b['is_winner'] == true ? ' 🏆' : ''}'),
            subtitle: Text('${b['rating'] != null ? '★ ${b['rating']}' : 'جديد'}${(b['warranty_days'] ?? 0) > 0 ? ' · ضمان ${b['warranty_days']} يوم' : ''}${b['is_lowest'] == true ? ' · الأقل' : ''}'),
            trailing: Text(money(b['price']), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
          ),
        ),
      if (isOwner && status == 'open') ...[
        const SizedBox(height: 8),
        if (d['mode'] == 'direct')
          FilledButton(onPressed: bids.isEmpty ? null : () => _do('accept'), child: const Text('قبول عرض الفني'))
        else
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: const Color(0xFF11261C)),
            onPressed: bids.isEmpty ? null : () async { if (await _confirm('إرساء الطلب الآن على أقل سعر؟')) _do('close'); },
            child: const Text('إنهاء المزاد الآن وإرساؤه على الأقل سعراً'),
          ),
      ],
      if (isOwner && (status == 'open' || status == 'awarded'))
        TextButton(
          style: TextButton.styleFrom(foregroundColor: Colors.red),
          onPressed: () async { if (await _confirm('هل تريد إلغاء الطلب؟')) _do('cancel'); },
          child: const Text('إلغاء الطلب'),
        ),
      if (isOwner && status == 'completed') _reviewBox(d),
      if (d['awarded_tech_id'] != null)
        TextButton(onPressed: _complain, child: const Text('⚠️ تقديم شكوى على هذا الطلب')),
    ]);
  }

  Widget _contact(String title, String phone, String sub, {String? geo}) => Card(
        color: const Color(0xFFFBF7EC),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
            Row(children: [
              FilledButton.icon(
                style: FilledButton.styleFrom(minimumSize: const Size(110, 40)),
                onPressed: () => launchUrl(Uri.parse('tel:$phone')),
                icon: const Icon(Icons.call),
                label: const Text('اتصال'),
              ),
              if (geo != null) ...[
                const SizedBox(width: 8),
                OutlinedButton.icon(onPressed: () => launchUrl(Uri.parse(geo), mode: LaunchMode.externalApplication), icon: const Icon(Icons.place), label: const Text('الموقع')),
              ],
              const SizedBox(width: 8),
              Text(phone, textDirection: TextDirection.ltr),
            ]),
            if (sub.isNotEmpty) Text(sub, style: const TextStyle(color: Colors.black54)),
          ]),
        ),
      );

  Widget _bidForm(Map<String, dynamic> d, Map<String, dynamic>? mine) => Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Text(mine != null ? 'اخفض سعرك للمنافسة' : 'قدّم سومتك', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
            if (d['lowest_price'] != null) Text('أقل سعر حالياً: ${money(d['lowest_price'])}${mine != null ? ' · سعرك ${money(mine['price'])} (الخفض فقط)' : ''}'),
            const SizedBox(height: 10),
            TextField(controller: price, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'السعر (ر.س)')),
            const SizedBox(height: 10),
            DropdownButtonFormField<int>(
              value: warranty,
              decoration: const InputDecoration(labelText: 'الضمان'),
              items: [0, 1, 3, 7, 30, 90].map((x) => DropdownMenuItem(value: x, child: Text(x == 0 ? 'بدون' : '$x يوم'))).toList(),
              onChanged: (v) => setState(() => warranty = v ?? 0),
            ),
            const SizedBox(height: 10),
            TextField(controller: eta, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'الوصول خلال (دقيقة)')),
            const SizedBox(height: 10),
            TextField(controller: note, maxLength: 300, decoration: const InputDecoration(labelText: 'ملاحظة')),
            FilledButton(
              onPressed: () => _do('bids', {'price': int.tryParse(price.text), 'warranty_days': warranty, if (int.tryParse(eta.text) != null) 'eta_minutes': int.parse(eta.text), if (note.text.isNotEmpty) 'note': note.text}),
              child: Text(mine != null ? 'تحديث السعر' : 'إرسال العرض'),
            ),
          ]),
        ),
      );

  Widget _reviewBox(Map<String, dynamic> d) {
    final rv = d['review'] as Map<String, dynamic>?;
    if (rv != null) {
      return Card(child: ListTile(title: const Text('تقييمك'), subtitle: Text('${'★' * (rv['stars'] as int)}\n${rv['comment'] ?? ''}')));
    }
    final allTags = ((Api.config['review_tags'] ?? []) as List).cast<String>();
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          const Text('قيّم الفني', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            for (var i = 1; i <= 5; i++)
              IconButton(iconSize: 36, onPressed: () => setState(() => stars = i), icon: Icon(i <= stars ? Icons.star : Icons.star_border, color: const Color(0xFFC9A227))),
          ]),
          Wrap(spacing: 8, children: [
            for (final t in allTags)
              FilterChip(label: Text(t), selected: tags.contains(t), onSelected: (v) => setState(() => v ? tags.add(t) : tags.remove(t))),
          ]),
          TextField(controller: comment, decoration: const InputDecoration(labelText: 'تعليق')),
          const SizedBox(height: 8),
          FilledButton(
            onPressed: stars == 0 ? null : () => _do('review', {'stars': stars, 'tags': tags.toList(), if (comment.text.isNotEmpty) 'comment': comment.text}),
            child: const Text('إرسال التقييم'),
          ),
        ]),
      ),
    );
  }

  Future<void> _complain() async {
    final c = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (x) => AlertDialog(
        title: const Text('تقديم شكوى'),
        content: TextField(controller: c, maxLines: 4, decoration: const InputDecoration(hintText: 'اكتب التفاصيل')),
        actions: [TextButton(onPressed: () => Navigator.pop(x, false), child: const Text('إلغاء')), TextButton(onPressed: () => Navigator.pop(x, true), child: const Text('إرسال'))],
      ),
    );
    if (ok == true) {
      try {
        await Api.post('/requests/${widget.id}/complaint', {'text': c.text});
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم استلام شكواك')));
      } catch (e) {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
      }
    }
  }
}
