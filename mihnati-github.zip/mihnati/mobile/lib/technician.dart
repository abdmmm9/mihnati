import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'api.dart';
import 'customer.dart' show currentPosition;
import 'request.dart';

class TechShell extends StatefulWidget {
  final VoidCallback onLogout;
  const TechShell({super.key, required this.onLogout});
  @override
  State<TechShell> createState() => _TechShellState();
}

class _TechShellState extends State<TechShell> {
  int tab = 0;
  @override
  Widget build(BuildContext context) {
    final tech = Api.user?['tech'] as Map<String, dynamic>?;
    if (tech == null || tech['has_id'] != true) return TechSetupScreen(onDone: () => setState(() {}));
    final pages = [const TechFeedPage(), const WalletPage(), _TechProfile(onLogout: widget.onLogout, onEdit: () => setState(() => tab = 3))];
    return Scaffold(
      appBar: AppBar(title: const Text('مهنتي — الفني')),
      body: tab == 3 ? TechSetupScreen(onDone: () => setState(() => tab = 0), embedded: true) : pages[tab],
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab > 2 ? 2 : tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.list_alt), label: 'الطلبات'),
          NavigationDestination(icon: Icon(Icons.account_balance_wallet_outlined), label: 'المحفظة'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'حسابي'),
        ],
      ),
    );
  }
}

class TechFeedPage extends StatefulWidget {
  const TechFeedPage({super.key});
  @override
  State<TechFeedPage> createState() => _TechFeedPageState();
}

class _TechFeedPageState extends State<TechFeedPage> {
  String scope = 'feed';
  late Future<Map<String, dynamic>> f = Api.get('/requests?scope=feed');
  void _reload() => setState(() => f = Api.get('/requests?scope=$scope'));

  @override
  Widget build(BuildContext context) {
    final t = Api.user!['tech'] as Map<String, dynamic>;
    final status = t['status'];
    return Column(children: [
      if (status == 'pending') Container(width: double.infinity, color: const Color(0xFFFBF7EC), padding: const EdgeInsets.all(12), child: const Text('⏳ حسابك قيد مراجعة الإدارة. يمكنك التقديم بعد الاعتماد.')),
      if (status == 'rejected') Container(width: double.infinity, color: const Color(0xFFFDE8E8), padding: const EdgeInsets.all(12), child: Text('❌ تم رفض التوثيق: ${t['reject_reason'] ?? ''}')),
      SwitchListTile(
        title: Text(t['online'] == true ? '🟢 متصل — تظهر للعملاء القريبين' : '⚪ غير متصل'),
        value: t['online'] == true,
        onChanged: (v) async {
          try {
            Map<String, dynamic> body = {'online': v};
            if (v) {
              try {
                final p = await currentPosition();
                body = {...body, 'lat': p.latitude, 'lng': p.longitude};
              } catch (_) {}
            }
            Api.user = await Api.post('/tech/status', body);
            setState(() {});
          } catch (e) {
            if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
          }
        },
      ),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12),
        child: SegmentedButton<String>(
          segments: const [ButtonSegment(value: 'feed', label: Text('المتاحة')), ButtonSegment(value: 'bids', label: Text('عروضي')), ButtonSegment(value: 'jobs', label: Text('أعمالي'))],
          selected: {scope},
          onSelectionChanged: (s) { scope = s.first; _reload(); },
        ),
      ),
      Expanded(
        child: RefreshIndicator(
          onRefresh: () async { _reload(); await f; },
          child: FutureBuilder<Map<String, dynamic>>(
            future: f,
            builder: (c, s) {
              if (s.hasError) return Center(child: Text('${s.error}'));
              if (!s.hasData) return const Center(child: CircularProgressIndicator());
              final list = (s.data!['requests'] as List).cast<Map<String, dynamic>>();
              if (list.isEmpty) return ListView(children: const [SizedBox(height: 100), Center(child: Text('لا توجد طلبات حالياً'))]);
              return ListView(padding: const EdgeInsets.all(12), children: [
                for (final r in list) RequestTile(r: r, onTap: () async { await Navigator.push(c, MaterialPageRoute(builder: (_) => RequestScreen(id: r['id']))); _reload(); }),
              ]);
            },
          ),
        ),
      ),
    ]);
  }
}

class WalletPage extends StatelessWidget {
  const WalletPage({super.key});
  @override
  Widget build(BuildContext context) => FutureBuilder<Map<String, dynamic>>(
        future: Api.get('/wallet'),
        builder: (c, s) {
          if (s.hasError) return Center(child: Text('${s.error}'));
          if (!s.hasData) return const Center(child: CircularProgressIndicator());
          final w = s.data!;
          const kinds = {'commission': 'عمولة المنصة', 'topup': 'شحن رصيد', 'adjustment': 'تسوية'};
          return ListView(padding: const EdgeInsets.all(16), children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(color: const Color(0xFF5A0D25), borderRadius: BorderRadius.circular(20)),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('الرصيد الحالي', style: TextStyle(color: Colors.white70)),
                Text('${w['balance']} ر.س', style: const TextStyle(color: Colors.white, fontSize: 38, fontWeight: FontWeight.bold), textDirection: TextDirection.ltr),
                Text('عمولة المنصة ${w['commission_pct']}% من كل عمل مكتمل. يتوقف التقديم عند رصيد أقل من −${w['max_debt']}', style: const TextStyle(color: Colors.white70)),
              ]),
            ),
            const SizedBox(height: 12),
            for (final t in (w['transactions'] as List).cast<Map<String, dynamic>>())
              Card(child: ListTile(
                title: Text(kinds[t['kind']] ?? '${t['kind']}'),
                subtitle: Text(DateTime.fromMillisecondsSinceEpoch(t['created_at'] as int).toString().substring(0, 16)),
                trailing: Text('${(t['amount'] as int) > 0 ? '+' : ''}${t['amount']}', style: TextStyle(fontWeight: FontWeight.bold, color: (t['amount'] as int) < 0 ? Colors.red : Colors.green), textDirection: TextDirection.ltr),
              )),
            const Padding(padding: EdgeInsets.all(12), child: Text('لشحن المحفظة تواصل مع الدعم: mhnty011@gmail.com')),
          ]);
        },
      );
}

class _TechProfile extends StatelessWidget {
  final VoidCallback onLogout, onEdit;
  const _TechProfile({required this.onLogout, required this.onEdit});
  @override
  Widget build(BuildContext context) {
    final u = Api.user!;
    final t = u['tech'] as Map<String, dynamic>;
    return ListView(padding: const EdgeInsets.all(16), children: [
      Card(child: Padding(padding: const EdgeInsets.all(20), child: Column(children: [
        Text('${u['name']}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        Text('${u['phone']}', textDirection: TextDirection.ltr),
        Text('★ ${t['rating'] ?? '—'} · ${t['jobs_done']} عمل'),
      ]))),
      FilledButton(onPressed: onEdit, child: const Text('تعديل بيانات الفني')),
      const SizedBox(height: 8),
      OutlinedButton(onPressed: () async { await Api.logout(); onLogout(); }, child: const Text('تسجيل الخروج')),
    ]);
  }
}

class TechSetupScreen extends StatefulWidget {
  final VoidCallback onDone;
  final bool embedded;
  const TechSetupScreen({super.key, required this.onDone, this.embedded = false});
  @override
  State<TechSetupScreen> createState() => _TechSetupScreenState();
}

class _TechSetupScreenState extends State<TechSetupScreen> {
  final idn = TextEditingController(), bio = TextEditingController(), years = TextEditingController(text: '0');
  late final Set<String> cats, zones;
  String? idPhoto;
  bool busy = false;

  @override
  void initState() {
    super.initState();
    final t = (Api.user?['tech'] ?? {}) as Map<String, dynamic>;
    cats = {...((t['categories'] ?? []) as List).cast<String>()};
    zones = {...((t['zones'] ?? []) as List).cast<String>()};
    bio.text = (t['bio'] ?? '') as String;
    years.text = '${t['experience_years'] ?? 0}';
  }

  @override
  Widget build(BuildContext context) {
    final allCats = ((Api.config['categories'] ?? []) as List).cast<Map<String, dynamic>>();
    final allZones = ((Api.config['zones'] ?? []) as List).cast<Map<String, dynamic>>();
    final hasId = ((Api.user?['tech'] ?? {}) as Map)['has_id'] == true;
    final body = ListView(padding: const EdgeInsets.all(16), children: [
      const Text('بيانات الفني والتوثيق', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      const SizedBox(height: 12),
      TextField(controller: idn, keyboardType: TextInputType.number, maxLength: 10, textDirection: TextDirection.ltr, decoration: const InputDecoration(labelText: 'رقم الهوية / الإقامة')),
      OutlinedButton.icon(
        icon: const Icon(Icons.badge),
        label: Text(idPhoto == null ? 'رفع صورة الهوية${hasId ? ' (اختياري)' : ''}' : '✅ تم الرفع'),
        onPressed: () async {
          try {
            final f = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 1600, imageQuality: 85);
            if (f == null) return;
            final url = await Api.upload(await f.readAsBytes(), kind: 'id');
            setState(() => idPhoto = url);
          } catch (e) {
            if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
          }
        },
      ),
      const SizedBox(height: 12),
      const Text('تخصصاتك', style: TextStyle(fontWeight: FontWeight.bold)),
      Wrap(spacing: 8, children: [for (final c in allCats) FilterChip(label: Text('${c['icon']} ${c['name']}'), selected: cats.contains(c['id']), onSelected: (v) => setState(() => v ? cats.add(c['id']) : cats.remove(c['id'])))]),
      const SizedBox(height: 12),
      const Text('المناطق التي تخدمها', style: TextStyle(fontWeight: FontWeight.bold)),
      Wrap(spacing: 8, children: [for (final z in allZones) FilterChip(label: Text('${z['name']}'), selected: zones.contains(z['id']), onSelected: (v) => setState(() => v ? zones.add(z['id']) : zones.remove(z['id'])))]),
      const SizedBox(height: 12),
      TextField(controller: years, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'سنوات الخبرة')),
      const SizedBox(height: 8),
      TextField(controller: bio, maxLines: 3, maxLength: 500, decoration: const InputDecoration(labelText: 'نبذة عنك')),
      FilledButton(
        onPressed: busy
            ? null
            : () async {
                if (!hasId && idPhoto == null) return ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('ارفع صورة الهوية')));
                setState(() => busy = true);
                try {
                  Api.user = await Api.post('/tech/profile', {
                    'id_number': idn.text,
                    if (idPhoto != null) 'id_photo': idPhoto,
                    'categories': cats.toList(),
                    'zones': zones.toList(),
                    'experience_years': int.tryParse(years.text) ?? 0,
                    'bio': bio.text,
                  });
                  widget.onDone();
                } catch (e) {
                  if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
                } finally {
                  if (mounted) setState(() => busy = false);
                }
              },
        child: const Text('حفظ وإرسال للمراجعة'),
      ),
    ]);
    return widget.embedded ? body : Scaffold(appBar: AppBar(title: const Text('إكمال بيانات الفني')), body: body);
  }
}
