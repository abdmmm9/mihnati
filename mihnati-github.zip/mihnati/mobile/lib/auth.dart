import 'package:flutter/material.dart';
import 'api.dart';

class LoginScreen extends StatefulWidget {
  final VoidCallback onDone;
  final VoidCallback onGuest;
  const LoginScreen({super.key, required this.onDone, required this.onGuest});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final phone = TextEditingController();
  final code = TextEditingController();
  final name = TextEditingController();
  bool codeSent = false, isNew = false, busy = false;
  String role = 'customer';

  Future<void> _run(Future<void> Function() f) async {
    setState(() => busy = true);
    try {
      await f();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('مهنتي')),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 460),
            child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              Image.asset('assets/icon.png', height: 110),
              const SizedBox(height: 12),
              const Text('سوق الخدمات الفنية الموثوق', textAlign: TextAlign.center, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 4),
              const Text('انشر طلبك والأقل سعراً يفوز', textAlign: TextAlign.center),
              const SizedBox(height: 24),
              TextField(
                controller: phone,
                enabled: !codeSent,
                keyboardType: TextInputType.phone,
                textDirection: TextDirection.ltr,
                decoration: const InputDecoration(labelText: 'رقم الجوال', hintText: '05xxxxxxxx'),
              ),
              if (codeSent) ...[
                const SizedBox(height: 12),
                TextField(
                  controller: code,
                  keyboardType: TextInputType.number,
                  maxLength: 6,
                  textDirection: TextDirection.ltr,
                  decoration: const InputDecoration(labelText: 'رمز التحقق (6 أرقام)'),
                ),
                if (isNew) ...[
                  TextField(controller: name, decoration: const InputDecoration(labelText: 'الاسم')),
                  const SizedBox(height: 12),
                  SegmentedButton<String>(
                    segments: const [
                      ButtonSegment(value: 'customer', label: Text('عميل')),
                      ButtonSegment(value: 'technician', label: Text('فني')),
                    ],
                    selected: {role},
                    onSelectionChanged: (s) => setState(() => role = s.first),
                  ),
                ],
              ],
              const SizedBox(height: 16),
              FilledButton(
                onPressed: busy
                    ? null
                    : () => _run(() async {
                          if (!codeSent) {
                            final r = await Api.post('/auth/otp', {'phone': phone.text});
                            setState(() {
                              codeSent = true;
                              isNew = r['new_user'] == true;
                            });
                          } else {
                            final r = await Api.post('/auth/verify', {'phone': phone.text, 'code': code.text, 'name': name.text, 'role': role});
                            await Api.setSession(r['token'] as String, r['user'] as Map<String, dynamic>);
                            widget.onDone();
                          }
                        }),
                child: Text(codeSent ? 'تأكيد' : 'إرسال الرمز'),
              ),
              if (codeSent) TextButton(onPressed: () => setState(() => codeSent = false), child: const Text('تغيير الرقم')),
            ]),
          ),
        ),
      ),
    );
  }
}
