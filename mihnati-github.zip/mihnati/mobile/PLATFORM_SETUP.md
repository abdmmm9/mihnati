# إعداد منصات Flutter (مرة واحدة)

مجلدات android/ و ios/ تُولَّد بأمر واحد حتى تبقى حزمة التطبيق نفسها المسجّلة في Play (`net.dellini.mihnati`):

```bash
cd mobile
flutter create --org net.dellini --project-name mihnati --platforms android,ios .
flutter pub get
```

## Android — `android/app/src/main/AndroidManifest.xml` (داخل `<manifest>`)
```xml
<uses-permission android:name="android.permission.INTERNET"/>
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>
<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION"/>
<queries><intent><action android:name="android.intent.action.DIAL"/></intent></queries>
```
وللتجربة على خادم http (غير https) أضف `android:usesCleartextTraffic="true"` على `<application>` — احذفها في النسخة النهائية.

## iOS — `ios/Runner/Info.plist`
```xml
<key>NSLocationWhenInUseUsageDescription</key><string>لعرض الفنيين القريبين وتحديد موقع الخدمة</string>
<key>NSPhotoLibraryUsageDescription</key><string>لإرفاق صور المشكلة أو وثيقة الهوية</string>
<key>LSApplicationQueriesSchemes</key><array><string>tel</string><string>https</string></array>
```

## التشغيل والبناء
```bash
flutter run --dart-define=API_BASE=https://your-domain.com
flutter build appbundle --release --dart-define=API_BASE=https://your-domain.com   # لـ Google Play
flutter build ipa --release --dart-define=API_BASE=https://your-domain.com         # لـ App Store (يتطلب Mac)
```

## التوقيع
استخدم نفس مفتاح الرفع القديم (`android.keystore`) إن كان لديك، وإلا فعّل Play App Signing وسجّل مفتاحاً جديداً.
بعد الرفع حدّث بصمة SHA-256 في `server/assetlinks.json` (انظر README الرئيسي).
