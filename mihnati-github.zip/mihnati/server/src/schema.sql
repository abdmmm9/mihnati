-- مخطط قاعدة بيانات مهنتي — متوافق مع PostgreSQL و SQLite (للتطوير والاختبار)
-- الأوقات: milliseconds منذ 1970 (BIGINT). الأسعار: ريال سعودي صحيح.

CREATE TABLE IF NOT EXISTS zones (
  id          TEXT PRIMARY KEY,
  name        TEXT NOT NULL,
  lat         DOUBLE PRECISION NOT NULL,
  lng         DOUBLE PRECISION NOT NULL,
  radius_km   INTEGER NOT NULL DEFAULT 30,
  active      INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS categories (
  id     TEXT PRIMARY KEY,
  name   TEXT NOT NULL,
  icon   TEXT NOT NULL,
  sort   INTEGER NOT NULL DEFAULT 0,
  active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS users (
  id          TEXT PRIMARY KEY,
  phone       TEXT NOT NULL UNIQUE,
  name        TEXT NOT NULL,
  role        TEXT NOT NULL,              -- customer | technician | admin
  avatar      TEXT,
  points      INTEGER NOT NULL DEFAULT 0,
  active      INTEGER NOT NULL DEFAULT 1,
  created_at  BIGINT NOT NULL
);

CREATE TABLE IF NOT EXISTS technician_profiles (
  user_id          TEXT PRIMARY KEY REFERENCES users(id),
  id_number        TEXT,
  id_photo         TEXT,                  -- ملف خاص (لا يُعرض للعامة)
  bio              TEXT,
  experience_years INTEGER NOT NULL DEFAULT 0,
  hourly_rate      INTEGER,
  status           TEXT NOT NULL DEFAULT 'pending',  -- pending | approved | rejected
  reject_reason    TEXT,
  online           INTEGER NOT NULL DEFAULT 0,
  lat              DOUBLE PRECISION,
  lng              DOUBLE PRECISION,
  last_seen        BIGINT,
  rating_sum       INTEGER NOT NULL DEFAULT 0,
  rating_count     INTEGER NOT NULL DEFAULT 0,
  jobs_done        INTEGER NOT NULL DEFAULT 0,
  wallet_balance   INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS tech_categories (
  user_id     TEXT NOT NULL REFERENCES users(id),
  category_id TEXT NOT NULL REFERENCES categories(id),
  PRIMARY KEY (user_id, category_id)
);

CREATE TABLE IF NOT EXISTS tech_zones (
  user_id TEXT NOT NULL REFERENCES users(id),
  zone_id TEXT NOT NULL REFERENCES zones(id),
  PRIMARY KEY (user_id, zone_id)
);

CREATE TABLE IF NOT EXISTS otps (
  id         TEXT PRIMARY KEY,
  phone      TEXT NOT NULL,
  code_hash  TEXT NOT NULL,
  expires_at BIGINT NOT NULL,
  attempts   INTEGER NOT NULL DEFAULT 0,
  used       INTEGER NOT NULL DEFAULT 0,
  created_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_otps_phone ON otps(phone, created_at);

CREATE TABLE IF NOT EXISTS requests (
  id              TEXT PRIMARY KEY,
  customer_id     TEXT NOT NULL REFERENCES users(id),
  category_id     TEXT NOT NULL REFERENCES categories(id),
  zone_id         TEXT NOT NULL REFERENCES zones(id),
  title           TEXT NOT NULL,
  description     TEXT NOT NULL,
  photos          TEXT NOT NULL DEFAULT '[]',
  lat             DOUBLE PRECISION NOT NULL,
  lng             DOUBLE PRECISION NOT NULL,
  address         TEXT,
  mode            TEXT NOT NULL DEFAULT 'auction',   -- auction | direct
  direct_tech_id  TEXT,
  status          TEXT NOT NULL DEFAULT 'open',
    -- open | awarded | on_the_way | arrived | in_progress | completed | cancelled | expired
  deadline_at     BIGINT NOT NULL,
  created_at      BIGINT NOT NULL,
  awarded_bid_id  TEXT,
  awarded_tech_id TEXT,
  awarded_at      BIGINT,
  final_price     INTEGER,
  warranty_days   INTEGER,
  completed_at    BIGINT
);
CREATE INDEX IF NOT EXISTS idx_requests_feed ON requests(status, zone_id, category_id);
CREATE INDEX IF NOT EXISTS idx_requests_customer ON requests(customer_id, created_at);
CREATE INDEX IF NOT EXISTS idx_requests_tech ON requests(awarded_tech_id);

CREATE TABLE IF NOT EXISTS bids (
  id            TEXT PRIMARY KEY,
  request_id    TEXT NOT NULL REFERENCES requests(id),
  tech_id       TEXT NOT NULL REFERENCES users(id),
  price         INTEGER NOT NULL,
  warranty_days INTEGER NOT NULL DEFAULT 0,
  eta_minutes   INTEGER,
  note          TEXT,
  created_at    BIGINT NOT NULL,
  price_at      BIGINT NOT NULL,          -- وقت آخر سعر (لكسر التعادل: الأسبق يفوز)
  UNIQUE (request_id, tech_id)
);
CREATE INDEX IF NOT EXISTS idx_bids_request ON bids(request_id, price);

CREATE TABLE IF NOT EXISTS reviews (
  id          TEXT PRIMARY KEY,
  request_id  TEXT NOT NULL UNIQUE REFERENCES requests(id),
  customer_id TEXT NOT NULL REFERENCES users(id),
  tech_id     TEXT NOT NULL REFERENCES users(id),
  stars       INTEGER NOT NULL,
  tags        TEXT NOT NULL DEFAULT '[]',
  comment     TEXT,
  created_at  BIGINT NOT NULL
);

CREATE TABLE IF NOT EXISTS wallet_tx (
  id         TEXT PRIMARY KEY,
  tech_id    TEXT NOT NULL REFERENCES users(id),
  amount     INTEGER NOT NULL,            -- موجب = إضافة، سالب = خصم
  kind       TEXT NOT NULL,               -- commission | topup | adjustment
  request_id TEXT,
  note       TEXT,
  created_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_wallet_tech ON wallet_tx(tech_id, created_at);

CREATE TABLE IF NOT EXISTS complaints (
  id          TEXT PRIMARY KEY,
  request_id  TEXT NOT NULL REFERENCES requests(id),
  user_id     TEXT NOT NULL REFERENCES users(id),
  against_id  TEXT,
  text        TEXT NOT NULL,
  status      TEXT NOT NULL DEFAULT 'open',   -- open | resolved
  resolution  TEXT,
  created_at  BIGINT NOT NULL
);

CREATE TABLE IF NOT EXISTS notifications (
  id         TEXT PRIMARY KEY,
  user_id    TEXT NOT NULL REFERENCES users(id),
  type       TEXT NOT NULL,
  payload    TEXT NOT NULL DEFAULT '{}',
  read       INTEGER NOT NULL DEFAULT 0,
  created_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_notif_user ON notifications(user_id, created_at);
