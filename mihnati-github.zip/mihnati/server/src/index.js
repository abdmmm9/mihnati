import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { createApp } from './app.js';
import { normPhone } from './util.js';

const rootDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const env = process.env;
const prod = env.NODE_ENV === 'production';

if (prod && !env.APP_SECRET) {
  console.error('APP_SECRET مطلوب في الإنتاج (سلسلة عشوائية طويلة).');
  process.exit(1);
}
if (prod && !env.DATABASE_URL) console.warn('تنبيه: DATABASE_URL غير مضبوط — سيُستخدم SQLite المحلي.');

const cfg = {
  rootDir,
  webDir: path.join(rootDir, 'web'),
  uploadDir: env.UPLOAD_DIR || path.join(rootDir, 'data/uploads'),
  databaseUrl: env.DATABASE_URL || '',
  sqlitePath: env.SQLITE_PATH || path.join(rootDir, 'data/mihnati.db'),
  secret: env.APP_SECRET || crypto.randomBytes(32).toString('hex'),
  adminPhone: env.ADMIN_PHONE ? normPhone(env.ADMIN_PHONE) : null,
  seedDemo: env.SEED_DEMO === '1',
  smsProvider: env.SMS_PROVIDER || 'console',
  smsWebhookUrl: env.SMS_WEBHOOK_URL || '',
  smsWebhookToken: env.SMS_WEBHOOK_TOKEN || '',
  showOtp: !prod && env.SHOW_OTP === '1',
  commissionPct: Number(env.COMMISSION_PCT ?? 10),
  maxDebt: Number(env.MAX_WALLET_DEBT ?? 200),
  pointsPerJob: Number(env.POINTS_PER_JOB ?? 5),
  defaultAuctionMinutes: Number(env.AUCTION_MINUTES ?? 60),
  trustProxy: env.TRUST_PROXY !== '0',
  sweepMs: 10000,
  log: true,
};

const app = await createApp(cfg);
const port = Number(env.PORT || 3000);
app.server.listen(port, () => console.log(`مهنتي يعمل على المنفذ ${port} (${app.db.kind})`));
for (const sig of ['SIGTERM', 'SIGINT']) process.on(sig, () => app.close().then(() => process.exit(0)));
