import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { createDb } from './db.js';
import { seed } from './seed.js';
import * as U from './util.js';
import { HttpError, now, uid } from './util.js';

const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8', '.webmanifest': 'application/manifest+json', '.png': 'image/png',
  '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.svg': 'image/svg+xml', '.ico': 'image/x-icon',
};
const REVIEW_TAGS = ['محترف', 'سريع في عمله', 'نظيف', 'ملتزم بالموعد', 'سعر عادل'];
const STATUS_FLOW = { awarded: 'on_the_way', on_the_way: 'arrived', arrived: 'in_progress', in_progress: 'completed' };
const DURATIONS = [15, 30, 60, 180, 1440]; // دقائق

export async function createApp(cfg) {
  const db = await createDb(cfg);
  await seed(db, cfg);
  fs.mkdirSync(path.join(cfg.uploadDir, 'public'), { recursive: true });
  fs.mkdirSync(path.join(cfg.uploadDir, 'private'), { recursive: true });

  // ---------- إشعارات لحظية (SSE) ----------
  const streams = new Map();
  async function notify(userId, type, payload = {}) {
    await db.run('INSERT INTO notifications (id,user_id,type,payload,created_at) VALUES (?,?,?,?,?)', [uid(), userId, type, JSON.stringify(payload), now()]).catch(() => {});
    for (const res of streams.get(userId) || []) res.write(`event: ${type}\ndata: ${JSON.stringify(payload)}\n\n`);
  }

  // ---------- SMS ----------
  async function sendSms(phone, text) {
    if (cfg.smsProvider === 'http' && cfg.smsWebhookUrl) {
      const r = await fetch(cfg.smsWebhookUrl, {
        method: 'POST',
        headers: { 'content-type': 'application/json', ...(cfg.smsWebhookToken ? { authorization: `Bearer ${cfg.smsWebhookToken}` } : {}) },
        body: JSON.stringify({ to: phone, text }),
      });
      if (!r.ok) throw new HttpError(502, 'تعذر إرسال الرسالة، حاول لاحقاً');
    } else if (cfg.log) console.log(`[SMS:console] ${phone} -> ${text}`);
  }

  // ---------- أدوات ----------
  const otpIpLimit = U.makeLimiter(20, 10 * 60e3);
  const apiLimit = U.makeLimiter(600, 60e3);

  const catName = async (id) => (await db.get('SELECT name FROM categories WHERE id=?', [id]))?.name;

  async function nearestZone(lat, lng) {
    const zones = await db.all('SELECT * FROM zones WHERE active=1');
    let best = null;
    for (const z of zones) {
      const d = U.haversineKm(lat, lng, z.lat, z.lng);
      if (d <= z.radius_km && (!best || d < best.d)) best = { z, d };
    }
    return best?.z || null;
  }

  async function techRows(ids) {
    if (!ids.length) return [];
    return db.all(
      `SELECT u.id, u.name, u.avatar, p.rating_sum, p.rating_count, p.status, p.experience_years, p.jobs_done, p.online
       FROM users u JOIN technician_profiles p ON p.user_id=u.id WHERE u.id IN (${ids.map(() => '?').join(',')})`, ids);
  }
  const ratingOf = (p) => (p.rating_count ? Math.round((p.rating_sum / p.rating_count) * 10) / 10 : null);

  // إغلاق المزاد: الأقل سعراً يفوز، والتعادل للأسبق في تثبيت السعر
  async function awardLowest(r) {
    const out = await db.tx(async (t) => {
      const cur = await t.get('SELECT * FROM requests WHERE id=?', [r.id]);
      if (!cur || cur.status !== 'open') return null;
      const best = await t.get('SELECT * FROM bids WHERE request_id=? ORDER BY price ASC, price_at ASC, id ASC LIMIT 1', [r.id]);
      if (!best) {
        await t.run("UPDATE requests SET status='expired' WHERE id=? AND status='open'", [r.id]);
        return { expired: true, req: cur };
      }
      const upd = await t.run(
        "UPDATE requests SET status='awarded', awarded_bid_id=?, awarded_tech_id=?, awarded_at=?, final_price=?, warranty_days=? WHERE id=? AND status='open'",
        [best.id, best.tech_id, now(), best.price, best.warranty_days, r.id]);
      if (!upd.changes) return null;
      const losers = await t.all('SELECT tech_id FROM bids WHERE request_id=? AND tech_id<>?', [r.id, best.tech_id]);
      return { best, req: cur, losers };
    });
    if (!out) return null;
    if (out.expired) {
      await notify(out.req.customer_id, 'request_expired', { request_id: r.id });
      return out;
    }
    await notify(out.best.tech_id, 'bid_won', { request_id: r.id, price: out.best.price });
    await notify(out.req.customer_id, 'request_awarded', { request_id: r.id, price: out.best.price });
    for (const l of out.losers) await notify(l.tech_id, 'bid_lost', { request_id: r.id });
    return out;
  }

  async function closeExpired() {
    const due = await db.all("SELECT * FROM requests WHERE status='open' AND deadline_at<=?", [now()]);
    for (const r of due) {
      if (r.mode === 'direct') {
        const upd = await db.run("UPDATE requests SET status='expired' WHERE id=? AND status='open'", [r.id]);
        if (upd.changes) await notify(r.customer_id, 'request_expired', { request_id: r.id });
      } else await awardLowest(r);
    }
  }

  // ---------- عرض الطلب حسب المشاهد ----------
  async function canTechSee(user, r) {
    if (r.awarded_tech_id === user.id) return true;
    if (await db.get('SELECT 1 AS x FROM bids WHERE request_id=? AND tech_id=?', [r.id, user.id])) return true;
    if (r.status !== 'open') return false;
    if (r.mode === 'direct' && r.direct_tech_id !== user.id) return false;
    const m = await db.get(
      `SELECT 1 AS x FROM tech_zones z JOIN tech_categories c ON c.user_id=z.user_id
       WHERE z.user_id=? AND z.zone_id=? AND c.category_id=?`, [user.id, r.zone_id, r.category_id]);
    return !!m;
  }

  async function requestView(id, viewer) {
    const r = await db.get(
      `SELECT r.*, c.name AS category_name, c.icon AS category_icon, z.name AS zone_name, cu.name AS customer_name, cu.phone AS customer_phone
       FROM requests r JOIN categories c ON c.id=r.category_id JOIN zones z ON z.id=r.zone_id JOIN users cu ON cu.id=r.customer_id WHERE r.id=?`, [id]);
    if (!r) throw new HttpError(404, 'الطلب غير موجود');
    const isOwner = r.customer_id === viewer.id, isAdmin = viewer.role === 'admin';
    if (!isOwner && !isAdmin && !(viewer.role === 'technician' && (await canTechSee(viewer, r)))) throw new HttpError(403, 'غير مسموح');

    const bids = await db.all('SELECT * FROM bids WHERE request_id=? ORDER BY price ASC, price_at ASC, id ASC', [id]);
    const techs = Object.fromEntries((await techRows([...new Set(bids.map((b) => b.tech_id))])).map((t) => [t.id, t]));
    const bidsOut = bids.map((b, i) => ({
      id: b.id, tech_id: b.tech_id, tech_name: techs[b.tech_id]?.name, tech_avatar: techs[b.tech_id]?.avatar,
      rating: techs[b.tech_id] ? ratingOf(techs[b.tech_id]) : null, rating_count: techs[b.tech_id]?.rating_count || 0,
      price: b.price, warranty_days: b.warranty_days, eta_minutes: b.eta_minutes, note: b.note,
      is_lowest: i === 0, is_winner: r.awarded_bid_id === b.id, mine: b.tech_id === viewer.id,
    }));

    const awardedToMe = r.awarded_tech_id === viewer.id;
    const reveal = r.awarded_tech_id && (isOwner || awardedToMe || isAdmin);
    const out = {
      id: r.id, title: r.title, description: r.description, photos: JSON.parse(r.photos || '[]'),
      category_id: r.category_id, category_name: r.category_name, category_icon: r.category_icon,
      zone_id: r.zone_id, zone_name: r.zone_name, mode: r.mode, status: r.status,
      deadline_at: r.deadline_at, created_at: r.created_at, now: now(),
      final_price: r.final_price, warranty_days: r.warranty_days, completed_at: r.completed_at,
      customer_name: r.customer_name, is_owner: isOwner,
      lat: isOwner || awardedToMe || isAdmin ? r.lat : U.approx(r.lat),
      lng: isOwner || awardedToMe || isAdmin ? r.lng : U.approx(r.lng),
      address: isOwner || awardedToMe || isAdmin ? r.address : null,
      bids: bidsOut, bids_count: bidsOut.length, lowest_price: bidsOut[0]?.price ?? null,
      my_bid: bidsOut.find((b) => b.mine) || null,
      awarded_tech_id: r.awarded_tech_id,
    };
    if (reveal) {
      out.customer_phone = r.customer_phone;
      if (r.awarded_tech_id) {
        const t = await db.get('SELECT name, phone FROM users WHERE id=?', [r.awarded_tech_id]);
        out.tech_name = t.name; out.tech_phone = t.phone;
      }
    }
    if (r.status === 'completed') {
      const rv = await db.get('SELECT stars, tags, comment FROM reviews WHERE request_id=?', [id]);
      out.review = rv ? { stars: rv.stars, tags: JSON.parse(rv.tags), comment: rv.comment } : null;
    }
    return out;
  }

  const SUMMARY = `SELECT r.id, r.title, r.status, r.mode, r.deadline_at, r.created_at, r.final_price, r.zone_id,
      c.name AS category_name, c.icon AS category_icon, z.name AS zone_name,
      (SELECT COUNT(*) FROM bids b WHERE b.request_id=r.id) AS bids_count,
      (SELECT MIN(price) FROM bids b WHERE b.request_id=r.id) AS lowest_price
    FROM requests r JOIN categories c ON c.id=r.category_id JOIN zones z ON z.id=r.zone_id`;

  // ---------- الراوتر ----------
  const routes = [];
  const route = (method, pattern, auth, handler) => {
    const keys = [];
    const rx = new RegExp('^' + pattern.replace(/:([a-z_]+)/gi, (_, k) => (keys.push(k), '([^/]+)')) + '$');
    routes.push({ method, rx, keys, auth, handler });
  };

  // --- عام ---
  route('GET', '/api/config', false, async () => ({
    categories: await db.all('SELECT id,name,icon FROM categories WHERE active=1 ORDER BY sort'),
    zones: await db.all('SELECT id,name,lat,lng,radius_km FROM zones WHERE active=1 ORDER BY name'),
    durations: DURATIONS, review_tags: REVIEW_TAGS, commission_pct: cfg.commissionPct,
  }));
  route('GET', '/api/health', false, async () => ({ ok: true, db: db.kind }));

  // --- الدخول ---
  route('POST', '/api/auth/otp', false, async ({ body, ip }) => {
    if (!otpIpLimit(ip)) throw new HttpError(429, 'محاولات كثيرة، حاول بعد قليل');
    const phone = U.normPhone(body.phone);
    if (!phone) throw new HttpError(400, 'رقم الجوال غير صحيح');
    const recent = await db.get('SELECT COUNT(*) AS n FROM otps WHERE phone=? AND created_at>?', [phone, now() - 10 * 60e3]);
    if (recent.n >= 3) throw new HttpError(429, 'تم إرسال عدة رموز، انتظر 10 دقائق');
    const code = cfg.fixedOtp || U.randomCode();
    await db.run('INSERT INTO otps (id,phone,code_hash,expires_at,created_at) VALUES (?,?,?,?,?)', [uid(), phone, U.hashCode(phone, code, cfg.secret), now() + 5 * 60e3, now()]);
    await sendSms(phone, `رمز التحقق في مهنتي: ${code}`);
    const exists = !!(await db.get('SELECT 1 AS x FROM users WHERE phone=?', [phone]));
    return { ok: true, new_user: !exists, ...(cfg.showOtp ? { dev_code: code } : {}) };
  });

  route('POST', '/api/auth/verify', false, async ({ body }) => {
    const phone = U.normPhone(body.phone);
    const code = String(body.code || '').trim();
    if (!phone || !/^\d{6}$/.test(code)) throw new HttpError(400, 'بيانات غير صحيحة');
    const otp = await db.get('SELECT * FROM otps WHERE phone=? AND used=0 AND expires_at>? ORDER BY created_at DESC LIMIT 1', [phone, now()]);
    if (!otp || otp.attempts >= 5) throw new HttpError(400, 'الرمز منتهي، اطلب رمزاً جديداً');
    if (!U.safeEqual(otp.code_hash, U.hashCode(phone, code, cfg.secret))) {
      await db.run('UPDATE otps SET attempts=attempts+1 WHERE id=?', [otp.id]);
      throw new HttpError(400, 'الرمز غير صحيح');
    }
    let user = await db.get('SELECT * FROM users WHERE phone=?', [phone]);
    if (user && !user.active) throw new HttpError(403, 'الحساب موقوف');
    const newName = user ? null : U.str(body.name, 2, 60, 'الاسم'); // قبل استهلاك الرمز
    await db.run('UPDATE otps SET used=1 WHERE id=?', [otp.id]);
    if (!user) {
      const name = newName;
      const role = body.role === 'technician' ? 'technician' : 'customer';
      const id = uid();
      await db.run('INSERT INTO users (id,phone,name,role,created_at) VALUES (?,?,?,?,?)', [id, phone, name, role, now()]);
      if (role === 'technician') await db.run('INSERT INTO technician_profiles (user_id) VALUES (?)', [id]);
      user = await db.get('SELECT * FROM users WHERE id=?', [id]);
    }
    const token = U.signToken({ uid: user.id, exp: now() + 30 * 86400e3 }, cfg.secret);
    return { token, user: await meView(user) };
  });

  async function meView(u) {
    const out = { id: u.id, phone: u.phone, name: u.name, role: u.role, avatar: u.avatar, points: u.points };
    if (u.role === 'technician') {
      const p = await db.get('SELECT * FROM technician_profiles WHERE user_id=?', [u.id]);
      out.tech = p && {
        status: p.status, reject_reason: p.reject_reason, online: !!p.online, bio: p.bio, experience_years: p.experience_years,
        hourly_rate: p.hourly_rate, rating: ratingOf(p), rating_count: p.rating_count, jobs_done: p.jobs_done, wallet_balance: p.wallet_balance,
        has_id: !!p.id_number,
        categories: (await db.all('SELECT category_id FROM tech_categories WHERE user_id=?', [u.id])).map((x) => x.category_id),
        zones: (await db.all('SELECT zone_id FROM tech_zones WHERE user_id=?', [u.id])).map((x) => x.zone_id),
      };
    }
    return out;
  }

  route('GET', '/api/me', true, async ({ user }) => meView(user));
  route('PATCH', '/api/me', true, async ({ user, body }) => {
    if (body.name !== undefined) await db.run('UPDATE users SET name=? WHERE id=?', [U.str(body.name, 2, 60, 'الاسم'), user.id]);
    if (body.avatar !== undefined) {
      if (body.avatar && !/^\/uploads\/public\/[\w.-]+$/.test(body.avatar)) throw new HttpError(400, 'صورة غير صحيحة');
      await db.run('UPDATE users SET avatar=? WHERE id=?', [body.avatar || null, user.id]);
    }
    return meView(await db.get('SELECT * FROM users WHERE id=?', [user.id]));
  });
  route('DELETE', '/api/me', true, async ({ user }) => {
    if (user.role === 'admin') throw new HttpError(400, 'لا يمكن حذف حساب المدير');
    const busy = await db.get("SELECT 1 AS x FROM requests WHERE (customer_id=? OR awarded_tech_id=?) AND status IN ('open','awarded','on_the_way','arrived','in_progress')", [user.id, user.id]);
    if (busy) throw new HttpError(400, 'لديك طلبات جارية، أنهِها أو ألغها أولاً');
    await db.run("UPDATE users SET name='حساب محذوف', phone=?, avatar=NULL, active=0 WHERE id=?", ['deleted:' + user.id, user.id]);
    await db.run("UPDATE technician_profiles SET online=0, id_number=NULL, id_photo=NULL WHERE user_id=?", [user.id]);
    return { ok: true };
  });

  // --- رفع الصور ---
  route('POST', '/api/uploads', true, async ({ user, body }) => {
    const buf = Buffer.from(String(body.data || ''), 'base64');
    if (buf.length < 100 || buf.length > 4 * 1024 * 1024) throw new HttpError(400, 'حجم الصورة غير مناسب (الحد 4MB)');
    let ext = null;
    if (buf[0] === 0xff && buf[1] === 0xd8) ext = 'jpg';
    else if (buf.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) ext = 'png';
    else if (buf.subarray(0, 4).toString() === 'RIFF' && buf.subarray(8, 12).toString() === 'WEBP') ext = 'webp';
    if (!ext) throw new HttpError(400, 'يُسمح بصور JPG/PNG/WEBP فقط');
    const kind = body.kind === 'id' ? 'private' : 'public';
    const name = `${user.id}_${uid()}.${ext}`;
    fs.writeFileSync(path.join(cfg.uploadDir, kind, name), buf);
    return { url: kind === 'private' ? `/api/files/${name}` : `/uploads/public/${name}` };
  });
  route('GET', '/api/files/:name', true, async ({ user, params, res }) => {
    const name = params.name;
    if (!/^[\w-]+\.(jpg|png|webp)$/.test(name)) throw new HttpError(404, 'غير موجود');
    if (!name.startsWith(user.id + '_') && user.role !== 'admin') throw new HttpError(403, 'غير مسموح');
    const f = path.join(cfg.uploadDir, 'private', name);
    if (!fs.existsSync(f)) throw new HttpError(404, 'غير موجود');
    res.writeHead(200, { 'content-type': MIME['.' + name.split('.').pop()], 'cache-control': 'private, max-age=300', 'x-content-type-options': 'nosniff' });
    res.end(fs.readFileSync(f));
    return undefined;
  });

  // --- الفني ---
  route('POST', '/api/tech/profile', 'technician', async ({ user, body }) => {
    const idNumber = String(body.id_number || '').trim();
    if (!/^\d{10}$/.test(idNumber)) throw new HttpError(400, 'رقم الهوية/الإقامة: 10 أرقام');
    if (body.id_photo && !new RegExp(`^/api/files/${user.id}_[\\w-]+\\.(jpg|png|webp)$`).test(body.id_photo)) throw new HttpError(400, 'صورة الهوية غير صحيحة');
    const cats = U.arr(body.categories), zones = U.arr(body.zones);
    if (!cats.length || !zones.length) throw new HttpError(400, 'اختر تخصصاً ومنطقة واحدة على الأقل');
    for (const c of cats) if (!(await db.get('SELECT 1 AS x FROM categories WHERE id=? AND active=1', [c]))) throw new HttpError(400, 'تخصص غير معروف');
    for (const z of zones) if (!(await db.get('SELECT 1 AS x FROM zones WHERE id=? AND active=1', [z]))) throw new HttpError(400, 'منطقة غير معروفة');
    const bio = body.bio ? U.str(body.bio, 0, 500, 'النبذة') : '';
    const years = U.int(body.experience_years ?? 0, 0, 60, 'سنوات الخبرة');
    const rate = body.hourly_rate ? U.int(body.hourly_rate, 1, 5000, 'سعر الساعة') : null;
    await db.tx(async (t) => {
      const old = await t.get('SELECT * FROM technician_profiles WHERE user_id=?', [user.id]);
      const reverify = !old || old.status !== 'approved' || old.id_number !== idNumber;
      await t.run(
        `UPDATE technician_profiles SET id_number=?, id_photo=COALESCE(?, id_photo), bio=?, experience_years=?, hourly_rate=?,
         status=?, reject_reason=NULL WHERE user_id=?`,
        [idNumber, body.id_photo || null, bio, years, rate, reverify ? 'pending' : 'approved', user.id]);
      await t.run('DELETE FROM tech_categories WHERE user_id=?', [user.id]);
      await t.run('DELETE FROM tech_zones WHERE user_id=?', [user.id]);
      for (const c of cats) await t.run('INSERT INTO tech_categories (user_id,category_id) VALUES (?,?)', [user.id, c]);
      for (const z of zones) await t.run('INSERT INTO tech_zones (user_id,zone_id) VALUES (?,?)', [user.id, z]);
    });
    return meView(user);
  });
  route('POST', '/api/tech/status', 'technician', async ({ user, body }) => {
    const lat = body.lat !== undefined ? U.num(body.lat, -90, 90, 'خط العرض') : null;
    const lng = body.lng !== undefined ? U.num(body.lng, -180, 180, 'خط الطول') : null;
    await db.run('UPDATE technician_profiles SET online=?, lat=COALESCE(?,lat), lng=COALESCE(?,lng), last_seen=? WHERE user_id=?', [body.online ? 1 : 0, lat, lng, now(), user.id]);
    return meView(user);
  });
  route('GET', '/api/technicians/:id', true, async ({ params }) => {
    const u = await db.get("SELECT id,name,avatar FROM users WHERE id=? AND role='technician' AND active=1", [params.id]);
    const p = u && (await db.get("SELECT * FROM technician_profiles WHERE user_id=? AND status='approved'", [params.id]));
    if (!p) throw new HttpError(404, 'الفني غير موجود');
    const cats = await db.all('SELECT c.id,c.name,c.icon FROM tech_categories tc JOIN categories c ON c.id=tc.category_id WHERE tc.user_id=?', [u.id]);
    const reviews = await db.all('SELECT stars,tags,comment,created_at FROM reviews WHERE tech_id=? ORDER BY created_at DESC LIMIT 10', [u.id]);
    return {
      id: u.id, name: u.name, avatar: u.avatar, bio: p.bio, experience_years: p.experience_years, hourly_rate: p.hourly_rate,
      rating: ratingOf(p), rating_count: p.rating_count, jobs_done: p.jobs_done, verified: true, online: !!p.online, categories: cats,
      reviews: reviews.map((r) => ({ ...r, tags: JSON.parse(r.tags) })),
    };
  });

  // --- الفنيون القريبون (طلب مباشر بدون مزاد) ---
  route('GET', '/api/nearby', true, async ({ query }) => {
    const lat = U.num(query.lat, -90, 90, 'خط العرض'), lng = U.num(query.lng, -180, 180, 'خط الطول');
    const km = Math.min(U.num(query.km ?? 10, 1, 50, 'المسافة'), 50);
    const dLat = km / 111, dLng = km / (111 * Math.max(Math.cos((lat * Math.PI) / 180), 0.2));
    const rows = await db.all(
      `SELECT u.id,u.name,u.avatar,p.lat,p.lng,p.online,p.rating_sum,p.rating_count FROM technician_profiles p JOIN users u ON u.id=p.user_id
       WHERE p.status='approved' AND u.active=1 AND p.online=1 AND p.lat BETWEEN ? AND ? AND p.lng BETWEEN ? AND ?`,
      [lat - dLat, lat + dLat, lng - dLng, lng + dLng]);
    const out = [];
    for (const r of rows) {
      const d = U.haversineKm(lat, lng, r.lat, r.lng);
      if (query.category && !(await db.get('SELECT 1 AS x FROM tech_categories WHERE user_id=? AND category_id=?', [r.id, query.category]))) continue;
      if (d <= km) out.push({ id: r.id, name: r.name, avatar: r.avatar, distance_km: Math.round(d * 10) / 10, lat: U.approx(r.lat), lng: U.approx(r.lng), rating: ratingOf(r), rating_count: r.rating_count,
        categories: (await db.all('SELECT category_id FROM tech_categories WHERE user_id=?', [r.id])).map((x) => x.category_id) });
    }
    return { technicians: out.sort((a, b) => a.distance_km - b.distance_km).slice(0, 50) };
  });

  // --- الطلبات ---
  route('POST', '/api/requests', 'customer', async ({ user, body }) => {
    const category = await db.get('SELECT * FROM categories WHERE id=? AND active=1', [body.category_id]);
    if (!category) throw new HttpError(400, 'اختر نوع الخدمة');
    const title = U.str(body.title || category.name, 3, 80, 'العنوان');
    const description = U.str(body.description, 5, 1000, 'وصف المشكلة');
    const lat = U.num(body.lat, -90, 90, 'الموقع'), lng = U.num(body.lng, -180, 180, 'الموقع');
    const photos = U.arr(body.photos, 5);
    for (const p of photos) if (!/^\/uploads\/public\/[\w.-]+$/.test(p)) throw new HttpError(400, 'صورة غير صحيحة');
    const zone = body.zone_id ? await db.get('SELECT * FROM zones WHERE id=? AND active=1', [body.zone_id]) : await nearestZone(lat, lng);
    if (!zone) throw new HttpError(400, 'الخدمة غير متاحة في موقعك حالياً');
    if (U.haversineKm(lat, lng, zone.lat, zone.lng) > zone.radius_km * 1.5) throw new HttpError(400, 'موقعك خارج نطاق المنطقة المختارة');
    const mode = body.direct_tech_id ? 'direct' : 'auction';
    let directId = null;
    if (mode === 'direct') {
      const t = await db.get("SELECT u.id FROM users u JOIN technician_profiles p ON p.user_id=u.id JOIN tech_categories c ON c.user_id=u.id WHERE u.id=? AND p.status='approved' AND u.active=1 AND c.category_id=?", [body.direct_tech_id, category.id]);
      if (!t) throw new HttpError(400, 'هذا الفني غير متاح لهذه الخدمة');
      directId = t.id;
    }
    const minutes = DURATIONS.includes(Number(body.duration_minutes)) ? Number(body.duration_minutes) : cfg.defaultAuctionMinutes;
    const active = await db.get("SELECT COUNT(*) AS n FROM requests WHERE customer_id=? AND status='open'", [user.id]);
    if (active.n >= 10) throw new HttpError(400, 'لديك عدة طلبات مفتوحة، أغلق بعضها أولاً');
    const id = uid();
    await db.run(
      `INSERT INTO requests (id,customer_id,category_id,zone_id,title,description,photos,lat,lng,address,mode,direct_tech_id,deadline_at,created_at)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      [id, user.id, category.id, zone.id, title, description, JSON.stringify(photos), lat, lng, body.address ? U.str(body.address, 0, 200, 'العنوان') : null, mode, directId, now() + minutes * 60e3, now()]);
    const techs = directId
      ? [{ user_id: directId }]
      : await db.all(
          `SELECT DISTINCT z.user_id FROM tech_zones z JOIN tech_categories c ON c.user_id=z.user_id
           JOIN technician_profiles p ON p.user_id=z.user_id JOIN users u ON u.id=z.user_id
           WHERE z.zone_id=? AND c.category_id=? AND p.status='approved' AND u.active=1`, [zone.id, category.id]);
    for (const t of techs) await notify(t.user_id, 'new_request', { request_id: id, title, category: category.name, zone: zone.name });
    return { id, notified: techs.length };
  });

  route('GET', '/api/requests', true, async ({ user, query }) => {
    if (user.role === 'customer') return { requests: await db.all(`${SUMMARY} WHERE r.customer_id=? ORDER BY r.created_at DESC LIMIT 100`, [user.id]) };
    if (user.role === 'admin') return { requests: await db.all(`${SUMMARY} ORDER BY r.created_at DESC LIMIT 200`) };
    if (query.scope === 'jobs')
      return { requests: await db.all(`${SUMMARY} WHERE r.awarded_tech_id=? ORDER BY r.created_at DESC LIMIT 100`, [user.id]) };
    if (query.scope === 'bids')
      return { requests: await db.all(`${SUMMARY} WHERE r.id IN (SELECT request_id FROM bids WHERE tech_id=?) AND r.status='open' ORDER BY r.created_at DESC LIMIT 100`, [user.id]) };
    return {
      requests: await db.all(
        `${SUMMARY} WHERE r.status='open' AND r.deadline_at>? AND r.zone_id IN (SELECT zone_id FROM tech_zones WHERE user_id=?)
         AND r.category_id IN (SELECT category_id FROM tech_categories WHERE user_id=?) AND (r.mode='auction' OR r.direct_tech_id=?)
         ORDER BY r.created_at DESC LIMIT 100`, [now(), user.id, user.id, user.id]),
    };
  });

  route('GET', '/api/requests/:id', true, async ({ user, params }) => requestView(params.id, user));

  route('POST', '/api/requests/:id/bids', 'technician', async ({ user, params, body }) => {
    const p = await db.get('SELECT * FROM technician_profiles WHERE user_id=?', [user.id]);
    if (!p || p.status !== 'approved') throw new HttpError(403, 'حسابك قيد المراجعة، لا يمكنك تقديم عروض بعد');
    if (p.wallet_balance < -cfg.maxDebt) throw new HttpError(403, `رصيد المحفظة أقل من الحد المسموح (-${cfg.maxDebt} ر.س). اشحن محفظتك`);
    const r = await db.get('SELECT * FROM requests WHERE id=?', [params.id]);
    if (!r) throw new HttpError(404, 'الطلب غير موجود');
    if (!(await canTechSee(user, r))) throw new HttpError(403, 'هذا الطلب خارج تخصصك أو منطقتك');
    if (r.status !== 'open' || r.deadline_at <= now()) throw new HttpError(400, 'انتهى وقت تقديم العروض');
    const price = U.int(body.price, 10, 100000, 'السعر');
    const warranty = U.int(body.warranty_days ?? 0, 0, 365, 'الضمان');
    const eta = body.eta_minutes ? U.int(body.eta_minutes, 5, 10080, 'وقت الوصول') : null;
    const note = body.note ? U.str(body.note, 0, 300, 'الملاحظة') : null;
    const before = await db.get('SELECT MIN(price) AS m FROM bids WHERE request_id=?', [r.id]);
    const prevLowBid = await db.get('SELECT tech_id FROM bids WHERE request_id=? ORDER BY price ASC, price_at ASC LIMIT 1', [r.id]);
    await db.tx(async (t) => {
      const mine = await t.get('SELECT * FROM bids WHERE request_id=? AND tech_id=?', [r.id, user.id]);
      if (mine) {
        // مزاد عكسي: يمكن خفض السعر فقط
        if (price >= mine.price) throw new HttpError(400, `يمكنك خفض سعرك فقط (سعرك الحالي ${mine.price} ر.س)`);
        await t.run('UPDATE bids SET price=?, warranty_days=?, eta_minutes=?, note=?, price_at=? WHERE id=?', [price, warranty, eta, note, now(), mine.id]);
      } else {
        await t.run('INSERT INTO bids (id,request_id,tech_id,price,warranty_days,eta_minutes,note,created_at,price_at) VALUES (?,?,?,?,?,?,?,?,?)', [uid(), r.id, user.id, price, warranty, eta, note, now(), now()]);
      }
    });
    await notify(r.customer_id, 'new_bid', { request_id: r.id, price, lowest: before.m === null || price < before.m });
    if (prevLowBid && prevLowBid.tech_id !== user.id && before.m !== null && price < before.m)
      await notify(prevLowBid.tech_id, 'outbid', { request_id: r.id, price });
    return requestView(r.id, user);
  });

  // العميل يقبل عرض الفني في الطلب المباشر
  route('POST', '/api/requests/:id/accept', 'customer', async ({ user, params }) => {
    const r = await db.get('SELECT * FROM requests WHERE id=? AND customer_id=?', [params.id, user.id]);
    if (!r) throw new HttpError(404, 'الطلب غير موجود');
    if (r.mode !== 'direct') throw new HttpError(400, 'هذا طلب مزاد، يُرسى تلقائياً على الأقل سعراً');
    if (r.status !== 'open') throw new HttpError(400, 'الطلب لم يعد مفتوحاً');
    const bid = await db.get('SELECT * FROM bids WHERE request_id=?', [r.id]);
    if (!bid) throw new HttpError(400, 'لم يصل عرض بعد');
    const upd = await db.run("UPDATE requests SET status='awarded', awarded_bid_id=?, awarded_tech_id=?, awarded_at=?, final_price=?, warranty_days=? WHERE id=? AND status='open'", [bid.id, bid.tech_id, now(), bid.price, bid.warranty_days, r.id]);
    if (!upd.changes) throw new HttpError(409, 'تم تحديث الطلب، أعد المحاولة');
    await notify(bid.tech_id, 'bid_won', { request_id: r.id, price: bid.price });
    return requestView(r.id, user);
  });

  // العميل ينهي المزاد الآن ويرسو على الأقل سعراً
  route('POST', '/api/requests/:id/close', 'customer', async ({ user, params }) => {
    const r = await db.get('SELECT * FROM requests WHERE id=? AND customer_id=?', [params.id, user.id]);
    if (!r) throw new HttpError(404, 'الطلب غير موجود');
    if (r.status !== 'open') throw new HttpError(400, 'الطلب لم يعد مفتوحاً');
    if (r.mode !== 'auction') throw new HttpError(400, 'استخدم قبول العرض للطلب المباشر');
    const out = await awardLowest(r);
    if (out?.expired) throw new HttpError(400, 'لا توجد عروض بعد');
    return requestView(r.id, user);
  });

  route('POST', '/api/requests/:id/cancel', 'customer', async ({ user, params }) => {
    const r = await db.get('SELECT * FROM requests WHERE id=? AND customer_id=?', [params.id, user.id]);
    if (!r) throw new HttpError(404, 'الطلب غير موجود');
    const upd = await db.run("UPDATE requests SET status='cancelled' WHERE id=? AND status IN ('open','awarded')", [r.id]);
    if (!upd.changes) throw new HttpError(400, 'لا يمكن إلغاء الطلب في هذه المرحلة، يمكنك تقديم شكوى');
    if (r.awarded_tech_id) await notify(r.awarded_tech_id, 'request_cancelled', { request_id: r.id });
    return requestView(r.id, user);
  });

  route('POST', '/api/requests/:id/status', 'technician', async ({ user, params, body }) => {
    const r = await db.get('SELECT * FROM requests WHERE id=? AND awarded_tech_id=?', [params.id, user.id]);
    if (!r) throw new HttpError(404, 'الطلب غير موجود');
    const next = STATUS_FLOW[r.status];
    if (!next || body.status !== next) throw new HttpError(400, 'تسلسل الحالة غير صحيح');
    await db.tx(async (t) => {
      const upd = await t.run('UPDATE requests SET status=?, completed_at=? WHERE id=? AND status=?', [next, next === 'completed' ? now() : null, r.id, r.status]);
      if (!upd.changes) throw new HttpError(409, 'تم تحديث الطلب، أعد المحاولة');
      if (next === 'completed') {
        const fee = Math.round((r.final_price * cfg.commissionPct) / 100);
        if (fee > 0) {
          await t.run('INSERT INTO wallet_tx (id,tech_id,amount,kind,request_id,note,created_at) VALUES (?,?,?,?,?,?,?)', [uid(), user.id, -fee, 'commission', r.id, `عمولة المنصة ${cfg.commissionPct}%`, now()]);
          await t.run('UPDATE technician_profiles SET wallet_balance=wallet_balance-?, jobs_done=jobs_done+1 WHERE user_id=?', [fee, user.id]);
        } else await t.run('UPDATE technician_profiles SET jobs_done=jobs_done+1 WHERE user_id=?', [user.id]);
        await t.run('UPDATE users SET points=points+? WHERE id=?', [cfg.pointsPerJob, r.customer_id]);
      }
    });
    await notify(r.customer_id, 'request_status', { request_id: r.id, status: next });
    return requestView(r.id, user);
  });

  route('POST', '/api/requests/:id/review', 'customer', async ({ user, params, body }) => {
    const r = await db.get('SELECT * FROM requests WHERE id=? AND customer_id=?', [params.id, user.id]);
    if (!r) throw new HttpError(404, 'الطلب غير موجود');
    if (r.status !== 'completed') throw new HttpError(400, 'يمكن التقييم بعد اكتمال الخدمة');
    const stars = U.int(body.stars, 1, 5, 'التقييم');
    const tags = U.arr(body.tags, 5).filter((x) => REVIEW_TAGS.includes(x));
    const comment = body.comment ? U.str(body.comment, 0, 500, 'التعليق') : null;
    await db.tx(async (t) => {
      if (await t.get('SELECT 1 AS x FROM reviews WHERE request_id=?', [r.id])) throw new HttpError(400, 'تم تقييم هذا الطلب سابقاً');
      await t.run('INSERT INTO reviews (id,request_id,customer_id,tech_id,stars,tags,comment,created_at) VALUES (?,?,?,?,?,?,?,?)', [uid(), r.id, user.id, r.awarded_tech_id, stars, JSON.stringify(tags), comment, now()]);
      await t.run('UPDATE technician_profiles SET rating_sum=rating_sum+?, rating_count=rating_count+1 WHERE user_id=?', [stars, r.awarded_tech_id]);
    });
    return requestView(r.id, user);
  });

  route('POST', '/api/requests/:id/complaint', true, async ({ user, params, body }) => {
    const r = await db.get('SELECT * FROM requests WHERE id=?', [params.id]);
    if (!r || (r.customer_id !== user.id && r.awarded_tech_id !== user.id)) throw new HttpError(404, 'الطلب غير موجود');
    const text = U.str(body.text, 5, 1000, 'نص الشكوى');
    const against = r.customer_id === user.id ? r.awarded_tech_id : r.customer_id;
    const id = uid();
    await db.run('INSERT INTO complaints (id,request_id,user_id,against_id,text,created_at) VALUES (?,?,?,?,?,?)', [id, r.id, user.id, against, text, now()]);
    return { id };
  });

  // --- المحفظة والنقاط ---
  route('GET', '/api/wallet', 'technician', async ({ user }) => {
    const p = await db.get('SELECT wallet_balance FROM technician_profiles WHERE user_id=?', [user.id]);
    return { balance: p?.wallet_balance ?? 0, max_debt: cfg.maxDebt, commission_pct: cfg.commissionPct,
      transactions: await db.all('SELECT id,amount,kind,note,request_id,created_at FROM wallet_tx WHERE tech_id=? ORDER BY created_at DESC LIMIT 100', [user.id]) };
  });

  route('GET', '/api/notifications', true, async ({ user }) => ({
    notifications: (await db.all('SELECT id,type,payload,read,created_at FROM notifications WHERE user_id=? ORDER BY created_at DESC LIMIT 50', [user.id])).map((n) => ({ ...n, payload: JSON.parse(n.payload) })),
  }));
  route('POST', '/api/notifications/read', true, async ({ user }) => {
    await db.run('UPDATE notifications SET read=1 WHERE user_id=?', [user.id]);
    return { ok: true };
  });

  // --- الإدارة ---
  route('GET', '/api/admin/stats', 'admin', async () => ({
    users: (await db.get("SELECT COUNT(*) AS n FROM users WHERE role='customer'")).n,
    technicians: (await db.get("SELECT COUNT(*) AS n FROM technician_profiles WHERE status='approved'")).n,
    pending_technicians: (await db.get("SELECT COUNT(*) AS n FROM technician_profiles WHERE status='pending' AND id_number IS NOT NULL")).n,
    requests: (await db.get('SELECT COUNT(*) AS n FROM requests')).n,
    open_requests: (await db.get("SELECT COUNT(*) AS n FROM requests WHERE status='open'")).n,
    completed: (await db.get("SELECT COUNT(*) AS n FROM requests WHERE status='completed'")).n,
    open_complaints: (await db.get("SELECT COUNT(*) AS n FROM complaints WHERE status='open'")).n,
    revenue: (await db.get("SELECT COALESCE(-SUM(amount),0) AS n FROM wallet_tx WHERE kind='commission'")).n,
  }));
  route('GET', '/api/admin/technicians', 'admin', async ({ query }) => ({
    technicians: await db.all(
      `SELECT u.id,u.name,u.phone,p.status,p.id_number,p.id_photo,p.experience_years,p.bio,p.wallet_balance,p.rating_count,u.active
       FROM technician_profiles p JOIN users u ON u.id=p.user_id WHERE p.status=? AND p.id_number IS NOT NULL ORDER BY u.created_at DESC LIMIT 200`, [query.status || 'pending']),
  }));
  route('POST', '/api/admin/technicians/:id/review', 'admin', async ({ params, body }) => {
    const approve = body.approve === true;
    const upd = await db.run('UPDATE technician_profiles SET status=?, reject_reason=? WHERE user_id=?', [approve ? 'approved' : 'rejected', approve ? null : U.str(body.reason, 3, 200, 'سبب الرفض'), params.id]);
    if (!upd.changes) throw new HttpError(404, 'الفني غير موجود');
    await notify(params.id, approve ? 'tech_approved' : 'tech_rejected', {});
    return { ok: true };
  });
  route('POST', '/api/admin/wallet', 'admin', async ({ body }) => {
    const amount = U.int(body.amount, -100000, 100000, 'المبلغ');
    if (!amount) throw new HttpError(400, 'المبلغ لا يمكن أن يكون صفراً');
    await db.tx(async (t) => {
      const upd = await t.run('UPDATE technician_profiles SET wallet_balance=wallet_balance+? WHERE user_id=?', [amount, body.tech_id]);
      if (!upd.changes) throw new HttpError(404, 'الفني غير موجود');
      await t.run('INSERT INTO wallet_tx (id,tech_id,amount,kind,note,created_at) VALUES (?,?,?,?,?,?)', [uid(), body.tech_id, amount, amount > 0 ? 'topup' : 'adjustment', body.note ? U.str(body.note, 0, 200, 'الملاحظة') : null, now()]);
    });
    return { ok: true };
  });
  route('GET', '/api/admin/complaints', 'admin', async () => ({
    complaints: await db.all(
      `SELECT c.*, u.name AS user_name, a.name AS against_name FROM complaints c JOIN users u ON u.id=c.user_id LEFT JOIN users a ON a.id=c.against_id ORDER BY c.status ASC, c.created_at DESC LIMIT 200`),
  }));
  route('POST', '/api/admin/complaints/:id/resolve', 'admin', async ({ params, body }) => {
    const upd = await db.run("UPDATE complaints SET status='resolved', resolution=? WHERE id=?", [U.str(body.resolution, 3, 500, 'القرار'), params.id]);
    if (!upd.changes) throw new HttpError(404, 'الشكوى غير موجودة');
    return { ok: true };
  });
  route('POST', '/api/admin/zones', 'admin', async ({ body }) => {
    const id = String(body.id || '').trim();
    if (!/^[a-z0-9-]{2,30}$/.test(id)) throw new HttpError(400, 'المعرّف: حروف إنجليزية صغيرة وأرقام');
    await db.run(
      'INSERT INTO zones (id,name,lat,lng,radius_km,active) VALUES (?,?,?,?,?,?) ON CONFLICT (id) DO UPDATE SET name=excluded.name, lat=excluded.lat, lng=excluded.lng, radius_km=excluded.radius_km, active=excluded.active',
      [id, U.str(body.name, 2, 60, 'الاسم'), U.num(body.lat, -90, 90, 'خط العرض'), U.num(body.lng, -180, 180, 'خط الطول'), U.int(body.radius_km ?? 30, 1, 200, 'النطاق'), body.active === false ? 0 : 1]);
    return { ok: true };
  });

  // ---------- الخادم ----------
  const readBody = (req, limit) =>
    new Promise((resolve, reject) => {
      const chunks = []; let size = 0;
      req.on('data', (c) => { size += c.length; if (size > limit) { reject(new HttpError(413, 'الحجم كبير')); req.destroy(); } else chunks.push(c); });
      req.on('end', () => {
        if (!chunks.length) return resolve({});
        try { const b = JSON.parse(Buffer.concat(chunks).toString()); resolve(b && typeof b === 'object' ? b : {}); }
        catch { reject(new HttpError(400, 'JSON غير صالح')); }
      });
      req.on('error', reject);
    });

  const send = (res, status, data) => {
    const body = JSON.stringify(data);
    res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' });
    res.end(body);
  };

  const authUser = async (token) => {
    const p = U.verifyToken(token, cfg.secret);
    if (!p) return null;
    const u = await db.get('SELECT * FROM users WHERE id=?', [p.uid]);
    return u && u.active ? u : null;
  };

  function serveStatic(req, res, pathname) {
    const secure = { 'x-content-type-options': 'nosniff', 'x-frame-options': 'SAMEORIGIN', 'referrer-policy': 'same-origin' };
    if (pathname === '/.well-known/assetlinks.json') {
      const f = path.join(cfg.rootDir, 'server/assetlinks.json');
      if (fs.existsSync(f)) { res.writeHead(200, { 'content-type': 'application/json', ...secure }); return res.end(fs.readFileSync(f)); }
    }
    let file;
    if (pathname.startsWith('/uploads/public/')) file = path.join(cfg.uploadDir, 'public', path.basename(pathname));
    else {
      const rel = pathname === '/' ? 'index.html' : pathname.replace(/^\/+/, '');
      file = path.normalize(path.join(cfg.webDir, rel));
      if (!file.startsWith(cfg.webDir + path.sep) && file !== cfg.webDir) { res.writeHead(403); return res.end(); }
    }
    if (!fs.existsSync(file) || fs.statSync(file).isDirectory()) {
      if (path.extname(pathname) && !pathname.endsWith('.html')) { res.writeHead(404); return res.end('Not found'); }
      const page = path.join(cfg.webDir, pathname.replace(/^\/+/, '') + '.html'); // /privacy -> privacy.html
      file = fs.existsSync(page) && pathname !== '/' ? page : path.join(cfg.webDir, 'index.html');
    }
    const ext = path.extname(file);
    const noCache = ext === '.html' || file.endsWith('sw.js') || ext === '.webmanifest';
    res.writeHead(200, { 'content-type': MIME[ext] || 'application/octet-stream', 'cache-control': noCache ? 'no-cache' : 'public, max-age=3600', ...secure });
    res.end(fs.readFileSync(file));
  }

  const server = http.createServer(async (req, res) => {
    const url = new URL(req.url, 'http://x');
    const ip = (cfg.trustProxy && req.headers['x-forwarded-for']?.split(',')[0].trim()) || req.socket.remoteAddress || '';
    try {
      if (!url.pathname.startsWith('/api/')) return serveStatic(req, res, decodeURIComponent(url.pathname));
      if (!apiLimit(ip)) throw new HttpError(429, 'طلبات كثيرة');

      // SSE
      if (url.pathname === '/api/events' && req.method === 'GET') {
        const user = await authUser(url.searchParams.get('token'));
        if (!user) throw new HttpError(401, 'غير مصرّح');
        res.writeHead(200, { 'content-type': 'text/event-stream', 'cache-control': 'no-store', connection: 'keep-alive', 'x-accel-buffering': 'no' });
        res.write('retry: 3000\n\n');
        if (!streams.has(user.id)) streams.set(user.id, new Set());
        streams.get(user.id).add(res);
        const ka = setInterval(() => res.write(': ping\n\n'), 25000);
        req.on('close', () => { clearInterval(ka); streams.get(user.id)?.delete(res); });
        return;
      }

      const m = routes.find((r) => r.method === req.method && r.rx.test(url.pathname));
      if (!m) throw new HttpError(404, 'المسار غير موجود');
      const params = {};
      const mm = url.pathname.match(m.rx);
      m.keys.forEach((k, i) => (params[k] = decodeURIComponent(mm[i + 1])));
      let user = null;
      if (m.auth) {
        const h = req.headers.authorization || '';
        user = await authUser(h.startsWith('Bearer ') ? h.slice(7) : '');
        if (!user) throw new HttpError(401, 'سجّل دخولك أولاً');
        if (typeof m.auth === 'string' && user.role !== m.auth) throw new HttpError(403, 'غير مسموح لهذا الحساب');
      }
      const body = req.method === 'GET' || req.method === 'DELETE' ? {} : await readBody(req, url.pathname === '/api/uploads' ? 7e6 : 64e3);
      const out = await m.handler({ req, res, params, query: Object.fromEntries(url.searchParams), body, user, ip });
      if (out !== undefined) send(res, 200, out);
    } catch (e) {
      if (res.headersSent) return res.end();
      if (e instanceof HttpError) return send(res, e.status, { error: e.message });
      console.error(e);
      send(res, 500, { error: 'خطأ في الخادم' });
    }
  });

  const timer = setInterval(() => closeExpired().catch((e) => console.error('closeExpired', e)), cfg.sweepMs);
  timer.unref();

  return {
    server, db, closeExpired,
    close: async () => { clearInterval(timer); for (const s of streams.values()) for (const r of s) r.end(); await new Promise((r) => server.close(r)); await db.close(); },
  };
}
