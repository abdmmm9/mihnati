// طبقة قاعدة البيانات: PostgreSQL في الإنتاج (DATABASE_URL) و SQLite للتطوير والاختبار.
// الاستعلامات تستخدم ? كعلامات مواضع وتُحوَّل تلقائياً إلى $1.. لـ PostgreSQL.
import fs from 'node:fs';
import path from 'node:path';

const schema = fs.readFileSync(new URL('./schema.sql', import.meta.url), 'utf8');

const toPg = (sql) => {
  let i = 0;
  return sql.replace(/\?/g, () => '$' + ++i);
};
const clean = (p) => p.map((v) => (v === undefined ? null : typeof v === 'boolean' ? Number(v) : v));

export async function createDb({ databaseUrl, sqlitePath }) {
  if (databaseUrl) return createPg(databaseUrl);
  return createSqlite(sqlitePath || ':memory:');
}

async function createPg(url) {
  const pg = (await import('pg')).default;
  pg.types.setTypeParser(20, (v) => Number(v)); // BIGINT
  pg.types.setTypeParser(1700, (v) => Number(v)); // NUMERIC
  const local = /localhost|127\.0\.0\.1|@postgres[:/]|@db[:/]/.test(url);
  const ssl = process.env.PGSSL === 'require' ? { rejectUnauthorized: false } : local || process.env.PGSSL === 'disable' ? false : { rejectUnauthorized: false };
  const pool = new pg.Pool({ connectionString: url, ssl, max: 10 });
  const wrap = (q) => ({
    all: async (sql, p = []) => (await q.query(toPg(sql), clean(p))).rows,
    get: async (sql, p = []) => (await q.query(toPg(sql), clean(p))).rows[0],
    run: async (sql, p = []) => ({ changes: (await q.query(toPg(sql), clean(p))).rowCount }),
  });
  await pool.query(schema);
  const base = wrap(pool);
  return {
    kind: 'postgres',
    ...base,
    async tx(fn) {
      const client = await pool.connect();
      try {
        await client.query('BEGIN');
        const r = await fn(wrap(client));
        await client.query('COMMIT');
        return r;
      } catch (e) {
        await client.query('ROLLBACK').catch(() => {});
        throw e;
      } finally {
        client.release();
      }
    },
    close: () => pool.end(),
  };
}

async function createSqlite(file) {
  const { DatabaseSync } = await import('node:sqlite');
  if (file !== ':memory:') fs.mkdirSync(path.dirname(path.resolve(file)), { recursive: true });
  const sdb = new DatabaseSync(file);
  sdb.exec('PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON;');
  sdb.exec(schema);
  const base = {
    all: async (sql, p = []) => sdb.prepare(sql).all(...clean(p)).map((r) => ({ ...r })),
    get: async (sql, p = []) => {
      const r = sdb.prepare(sql).get(...clean(p));
      return r ? { ...r } : undefined;
    },
    run: async (sql, p = []) => ({ changes: Number(sdb.prepare(sql).run(...clean(p)).changes) }),
  };
  let chain = Promise.resolve();
  return {
    kind: 'sqlite',
    ...base,
    // SQLite: اتصال واحد، فنُسلسل المعاملات حتى لا تتداخل
    tx(fn) {
      const run = chain.then(async () => {
        sdb.exec('BEGIN');
        try {
          const r = await fn(base);
          sdb.exec('COMMIT');
          return r;
        } catch (e) {
          sdb.exec('ROLLBACK');
          throw e;
        }
      });
      chain = run.catch(() => {});
      return run;
    },
    close: () => sdb.close(),
  };
}
