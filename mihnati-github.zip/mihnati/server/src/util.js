import crypto from 'node:crypto';

export class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

export const now = () => Date.now();
export const uid = () => crypto.randomUUID();

// ---- الجوال ----
export function normPhone(input) {
  let p = String(input || '').replace(/[\s\-()]/g, '');
  // أرقام عربية/هندية -> لاتينية
  p = p.replace(/[٠-٩]/g, (d) => '٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(/[۰-۹]/g, (d) => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d));
  if (p.startsWith('00')) p = '+' + p.slice(2);
  else if (/^05\d{8}$/.test(p)) p = '+966' + p.slice(1);
  else if (/^5\d{8}$/.test(p)) p = '+966' + p;
  else if (/^9665\d{8}$/.test(p)) p = '+' + p;
  return /^\+\d{10,15}$/.test(p) ? p : null;
}

// ---- الرموز ----
export const randomCode = () => String(crypto.randomInt(0, 1000000)).padStart(6, '0');
export const hashCode = (phone, code, secret) =>
  crypto.createHmac('sha256', secret).update(`${phone}:${code}`).digest('hex');
export const safeEqual = (a, b) => {
  const A = Buffer.from(a), B = Buffer.from(b);
  return A.length === B.length && crypto.timingSafeEqual(A, B);
};

const b64u = (b) => Buffer.from(b).toString('base64url');
export function signToken(payload, secret) {
  const body = b64u(JSON.stringify(payload));
  const sig = crypto.createHmac('sha256', secret).update(body).digest('base64url');
  return `${body}.${sig}`;
}
export function verifyToken(token, secret) {
  if (typeof token !== 'string') return null;
  const [body, sig] = token.split('.');
  if (!body || !sig) return null;
  const expect = crypto.createHmac('sha256', secret).update(body).digest('base64url');
  if (!safeEqual(sig, expect)) return null;
  try {
    const p = JSON.parse(Buffer.from(body, 'base64url').toString());
    return p.exp > Date.now() ? p : null;
  } catch {
    return null;
  }
}

// ---- الجغرافيا ----
export function haversineKm(lat1, lng1, lat2, lng2) {
  const R = 6371, rad = (d) => (d * Math.PI) / 180;
  const dLat = rad(lat2 - lat1), dLng = rad(lng2 - lng1);
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(rad(lat1)) * Math.cos(rad(lat2)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(a));
}
export const approx = (n) => Math.round(n * 100) / 100; // ~1كم — لإخفاء الموقع الدقيق

// ---- التحقق ----
export const str = (v, min, max, label) => {
  const s = typeof v === 'string' ? v.trim() : '';
  if (s.length < min || s.length > max) throw new HttpError(400, `${label}: من ${min} إلى ${max} حرفاً`);
  return s;
};
export const int = (v, min, max, label) => {
  const n = Number(v);
  if (!Number.isInteger(n) || n < min || n > max) throw new HttpError(400, `${label}: رقم صحيح بين ${min} و ${max}`);
  return n;
};
export const num = (v, min, max, label) => {
  const n = Number(v);
  if (!Number.isFinite(n) || n < min || n > max) throw new HttpError(400, `${label} غير صحيح`);
  return n;
};
export const arr = (v, max = 50) => (Array.isArray(v) ? v.filter((x) => typeof x === 'string').slice(0, max) : []);

// ---- حد الطلبات (في الذاكرة) ----
export function makeLimiter(limit, windowMs) {
  const hits = new Map();
  return (key) => {
    const t = Date.now();
    const arr = (hits.get(key) || []).filter((x) => t - x < windowMs);
    if (arr.length >= limit) { hits.set(key, arr); return false; }
    arr.push(t);
    hits.set(key, arr);
    if (hits.size > 5000) for (const [k, v] of hits) if (!v.length || t - v[v.length - 1] > windowMs) hits.delete(k);
    return true;
  };
}
