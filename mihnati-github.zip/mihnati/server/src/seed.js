import { uid, now } from './util.js';

export const CATEGORIES = [
  ['ac', 'فني تكييف', '❄️'],
  ['plumber', 'سباك', '🔧'],
  ['electrician', 'كهربائي', '⚡'],
  ['carpenter', 'نجار', '🔨'],
  ['painter', 'دهان', '🎨'],
  ['mechanic', 'ميكانيكي', '🚗'],
];

// المناطق (الزونات): الفنيون داخل المنطقة هم من يستلمون الطلبات
export const ZONES = [
  ['riyadh', 'الرياض', 24.7136, 46.6753, 45],
  ['jeddah', 'جدة', 21.4858, 39.1925, 40],
  ['makkah', 'مكة المكرمة', 21.3891, 39.8579, 30],
  ['madinah', 'المدينة المنورة', 24.5247, 39.5692, 30],
  ['dammam', 'الدمام', 26.4207, 50.0888, 30],
  ['khobar', 'الخبر', 26.2172, 50.1971, 20],
  ['taif', 'الطائف', 21.2854, 40.4183, 25],
  ['abha', 'أبها', 18.2164, 42.5053, 25],
  ['khamis', 'خميس مشيط', 18.3093, 42.7298, 25],
  ['tabuk', 'تبوك', 28.3838, 36.5550, 30],
  ['buraydah', 'بريدة', 26.326, 43.975, 30],
  ['najran', 'نجران', 17.4917, 44.1322, 25],
  ['jazan', 'جازان', 16.8892, 42.5511, 25],
  ['hail', 'حائل', 27.5114, 41.7208, 30],
];

export async function seed(db, cfg) {
  for (const [i, [id, name, icon]] of CATEGORIES.entries())
    await db.run('INSERT INTO categories (id,name,icon,sort) VALUES (?,?,?,?) ON CONFLICT (id) DO NOTHING', [id, name, icon, i]);
  for (const [id, name, lat, lng, r] of ZONES)
    await db.run('INSERT INTO zones (id,name,lat,lng,radius_km) VALUES (?,?,?,?,?) ON CONFLICT (id) DO NOTHING', [id, name, lat, lng, r]);

  if (cfg.adminPhone) {
    const a = await db.get('SELECT id FROM users WHERE phone=?', [cfg.adminPhone]);
    if (!a) await db.run('INSERT INTO users (id,phone,name,role,created_at) VALUES (?,?,?,?,?)', [uid(), cfg.adminPhone, 'مدير النظام', 'admin', now()]);
    else await db.run("UPDATE users SET role='admin' WHERE id=?", [a.id]);
  }

  if (cfg.seedDemo) {
    const has = await db.get("SELECT 1 AS x FROM users WHERE phone='+966550000001'");
    if (has) return;
    const demo = [
      ['+966550000001', 'مؤسسة النسيم للتكييف', 'ac', 'khamis', 18.3093, 42.7298, 9],
      ['+966550000002', 'فني تخصصين', 'ac', 'khamis', 18.3180, 42.7400, 9],
      ['+966550000003', 'أبو ياسر للسباكة', 'plumber', 'khamis', 18.30, 42.72, 6],
      ['+966550000004', 'ورشة الكهرباء الحديثة', 'electrician', 'abha', 18.2164, 42.5053, 12],
    ];
    for (const [phone, name, cat, zone, lat, lng, years] of demo) {
      const id = uid();
      await db.run('INSERT INTO users (id,phone,name,role,created_at) VALUES (?,?,?,?,?)', [id, phone, name, 'technician', now()]);
      await db.run(
        "INSERT INTO technician_profiles (user_id,id_number,bio,experience_years,status,online,lat,lng,last_seen) VALUES (?,?,?,?,'approved',1,?,?,?)",
        [id, '1000000000', 'فني معتمد — بيانات تجريبية', years, lat, lng, now()],
      );
      await db.run('INSERT INTO tech_categories (user_id,category_id) VALUES (?,?)', [id, cat]);
      await db.run('INSERT INTO tech_zones (user_id,zone_id) VALUES (?,?)', [id, zone]);
    }
  }
}
