import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import os from 'node:os';
import path from 'node:path';
import fs from 'node:fs';
import { createApp } from '../src/app.js';

let app, base;
const cfg = {
  rootDir: path.resolve(import.meta.dirname, '../..'),
  webDir: path.resolve(import.meta.dirname, '../../web'),
  uploadDir: fs.mkdtempSync(path.join(os.tmpdir(), 'mih-')),
  sqlitePath: ':memory:', databaseUrl: process.env.TEST_DATABASE_URL || '', secret: 'test-secret', adminPhone: '+966500000000', seedDemo: false,
  smsProvider: 'console', showOtp: false, fixedOtp: '123456', commissionPct: 10, maxDebt: 200, pointsPerJob: 5,
  defaultAuctionMinutes: 60, trustProxy: false, sweepMs: 3600e3, log: false,
};

const call = async (method, url, body, token) => {
  const r = await fetch(base + url, { method, headers: { 'content-type': 'application/json', ...(token ? { authorization: `Bearer ${token}` } : {}) }, body: body ? JSON.stringify(body) : undefined });
  const j = await r.json().catch(() => ({}));
  return { status: r.status, ...j };
};
let phoneSeq = 0;
async function signup(role, name) {
  const phone = `05${String(10000000 + ++phoneSeq)}`;
  await call('POST', '/api/auth/otp', { phone });
  const r = await call('POST', '/api/auth/verify', { phone, code: '123456', name, role });
  assert.ok(r.token, JSON.stringify(r));
  return r;
}
async function approvedTech(name, cat = 'ac', zone = 'khamis') {
  const t = await signup('technician', name);
  const p = await call('POST', '/api/tech/profile', { id_number: '1234567890', categories: [cat], zones: [zone], experience_years: 5 }, t.token);
  assert.equal(p.tech.status, 'pending');
  await app.db.run("UPDATE technician_profiles SET status='approved' WHERE user_id=?", [t.user.id]);
  return t;
}
const reqBody = { category_id: 'ac', description: 'المكيف لا يبرّد', lat: 18.3093, lng: 42.7298, duration_minutes: 30 };

before(async () => {
  app = await createApp(cfg);
  await new Promise((r) => app.server.listen(0, r));
  base = `http://127.0.0.1:${app.server.address().port}`;
});
after(async () => app.close());

test('OTP: رقم خاطئ ورمز خاطئ ودخول صحيح', async () => {
  assert.equal((await call('POST', '/api/auth/otp', { phone: '123' })).status, 400);
  const phone = '0512345678';
  const o = await call('POST', '/api/auth/otp', { phone });
  assert.equal(o.new_user, true);
  assert.equal(o.dev_code, undefined, 'لا يجب كشف الرمز');
  assert.equal((await call('POST', '/api/auth/verify', { phone, code: '000000', name: 'سعد' })).status, 400);
  assert.equal((await call('POST', '/api/auth/verify', { phone, code: '123456' })).status, 400, 'الاسم مطلوب للمستخدم الجديد');
  const ok = await call('POST', '/api/auth/verify', { phone, code: '123456', name: 'سعد', role: 'customer' });
  assert.equal(ok.user.phone, '+966512345678');
  assert.equal((await call('GET', '/api/me', null, ok.token)).name, 'سعد');
  assert.equal((await call('GET', '/api/me')).status, 401);
});

test('المزاد: الأقل سعراً يفوز، والخفض فقط، وكشف التواصل بعد الإرساء', async () => {
  const cust = await signup('customer', 'عميل');
  const a = await approvedTech('فني أ'), b = await approvedTech('فني ب'), c = await approvedTech('فني ج');
  const other = await approvedTech('فني سباك', 'plumber'); // تخصص آخر
  const outside = await approvedTech('فني أبها', 'ac', 'abha'); // منطقة أخرى

  const created = await call('POST', '/api/requests', reqBody, cust.token);
  assert.equal(created.notified, 3, 'يصل الطلب للفنيين في المنطقة والتخصص فقط');
  const id = created.id;

  assert.equal((await call('POST', `/api/requests/${id}/bids`, { price: 200 }, other.token)).status, 403);
  assert.equal((await call('POST', `/api/requests/${id}/bids`, { price: 200 }, outside.token)).status, 403);
  assert.equal((await call('GET', `/api/requests/${id}`, null, other.token)).status, 403);

  await call('POST', `/api/requests/${id}/bids`, { price: 300, warranty_days: 30 }, a.token);
  await call('POST', `/api/requests/${id}/bids`, { price: 250, warranty_days: 7 }, b.token);
  const r3 = await call('POST', `/api/requests/${id}/bids`, { price: 250 }, c.token); // تعادل مع ب — ب أسبق
  assert.equal(r3.lowest_price, 250);

  const up = await call('POST', `/api/requests/${id}/bids`, { price: 400 }, a.token);
  assert.equal(up.status, 400, 'لا يمكن رفع السعر');
  assert.equal((await call('POST', `/api/requests/${id}/bids`, { price: 300 }, a.token)).status, 400);

  let view = await call('GET', `/api/requests/${id}`, null, cust.token);
  assert.deepEqual(view.bids.map((x) => x.price), [250, 250, 300]);
  assert.equal(view.bids[0].tech_name, 'فني ب');
  assert.equal(view.customer_phone, undefined, 'الجوال مخفي قبل الإرساء');
  const techView = await call('GET', `/api/requests/${id}`, null, a.token);
  assert.equal(techView.address, null);
  assert.equal(techView.customer_phone, undefined);

  // الفني أ يخفض إلى 240 فيفوز
  await call('POST', `/api/requests/${id}/bids`, { price: 240 }, a.token);
  await app.db.run('UPDATE requests SET deadline_at=? WHERE id=?', [Date.now() - 1000, id]);
  await app.closeExpired();

  view = await call('GET', `/api/requests/${id}`, null, cust.token);
  assert.equal(view.status, 'awarded');
  assert.equal(view.final_price, 240);
  assert.equal(view.awarded_tech_id, a.user.id);
  assert.equal(view.tech_phone, a.user.phone);
  assert.equal((await call('GET', `/api/requests/${id}`, null, a.token)).customer_phone, cust.user.phone);
  assert.equal((await call('GET', `/api/requests/${id}`, null, b.token)).customer_phone, undefined, 'الخاسر لا يرى الجوال');
  assert.equal((await call('POST', `/api/requests/${id}/bids`, { price: 100 }, b.token)).status, 400, 'المزاد مغلق');

  // تسلسل الحالات
  assert.equal((await call('POST', `/api/requests/${id}/status`, { status: 'completed' }, a.token)).status, 400);
  assert.equal((await call('POST', `/api/requests/${id}/status`, { status: 'completed' }, b.token)).status, 404);
  for (const s of ['on_the_way', 'arrived', 'in_progress', 'completed'])
    assert.equal((await call('POST', `/api/requests/${id}/status`, { status: s }, a.token)).status, s);

  // العمولة 10% = 24
  const w = await call('GET', '/api/wallet', null, a.token);
  assert.equal(w.balance, -24);
  assert.equal(w.transactions[0].kind, 'commission');
  assert.equal((await call('GET', '/api/me', null, cust.token)).points, 5);

  // التقييم
  assert.equal((await call('POST', `/api/requests/${id}/review`, { stars: 6 }, cust.token)).status, 400);
  const rv = await call('POST', `/api/requests/${id}/review`, { stars: 5, tags: ['محترف', 'غير موجود'], comment: 'ممتاز' }, cust.token);
  assert.deepEqual(rv.review.tags, ['محترف']);
  assert.equal((await call('POST', `/api/requests/${id}/review`, { stars: 4 }, cust.token)).status, 400, 'تقييم واحد فقط');
  const prof = await call('GET', `/api/technicians/${a.user.id}`, null, cust.token);
  assert.equal(prof.rating, 5);
  assert.equal(prof.jobs_done, 1);
});

test('انتهاء المزاد بدون عروض، والإلغاء، وإنهاء المزاد مبكراً', async () => {
  const cust = await signup('customer', 'عميل 2');
  const t = await approvedTech('فني د');
  const { id } = await call('POST', '/api/requests', reqBody, cust.token);
  assert.equal((await call('POST', `/api/requests/${id}/close`, null, cust.token)).status, 400, 'لا عروض');
  await app.db.run('UPDATE requests SET deadline_at=? WHERE id=?', [Date.now() - 1, id]);
  await app.closeExpired();
  assert.equal((await call('GET', `/api/requests/${id}`, null, cust.token)).status, 'expired');

  const r2 = await call('POST', '/api/requests', reqBody, cust.token);
  await call('POST', `/api/requests/${r2.id}/bids`, { price: 180 }, t.token);
  const closed = await call('POST', `/api/requests/${r2.id}/close`, null, cust.token);
  assert.equal(closed.status, 'awarded');
  assert.equal(closed.final_price, 180);
  assert.equal((await call('POST', `/api/requests/${r2.id}/cancel`, null, cust.token)).status, 'cancelled');
  assert.equal((await call('POST', `/api/requests/${r2.id}/cancel`, null, cust.token)).status, 400);
});

test('الطلب المباشر: فني واحد والعميل يقبل', async () => {
  const cust = await signup('customer', 'عميل 3');
  const t = await approvedTech('فني قريب');
  const t2 = await approvedTech('فني آخر');
  await call('POST', '/api/tech/status', { online: true, lat: 18.31, lng: 42.73 }, t.token);
  const near = await call('GET', '/api/nearby?lat=18.3093&lng=42.7298&km=10&category=ac', null, cust.token);
  assert.ok(near.technicians.some((x) => x.id === t.user.id));
  assert.ok(!near.technicians.some((x) => x.id === t2.user.id), 'غير متصل');
  assert.equal(near.technicians[0].phone, undefined);

  const { id } = await call('POST', '/api/requests', { ...reqBody, direct_tech_id: t.user.id }, cust.token);
  assert.equal((await call('POST', `/api/requests/${id}/bids`, { price: 150 }, t2.token)).status, 403, 'ليس موجهاً له');
  await call('POST', `/api/requests/${id}/bids`, { price: 150 }, t.token);
  assert.equal((await call('GET', `/api/requests/${id}`, null, cust.token)).status, 'open', 'لا إرساء تلقائي في المباشر');
  assert.equal((await call('POST', `/api/requests/${id}/accept`, null, cust.token)).status, 'awarded');
});

test('الفني غير المعتمد لا يقدم عروضاً، والإدارة تعتمده', async () => {
  const cust = await signup('customer', 'عميل 4');
  const t = await signup('technician', 'فني جديد');
  await call('POST', '/api/tech/profile', { id_number: '1234567890', categories: ['ac'], zones: ['khamis'] }, t.token);
  const { id } = await call('POST', '/api/requests', reqBody, cust.token);
  assert.equal((await call('POST', `/api/requests/${id}/bids`, { price: 100 }, t.token)).status, 403);

  await call('POST', '/api/auth/otp', { phone: '0500000000' });
  const admin = await call('POST', '/api/auth/verify', { phone: '0500000000', code: '123456', name: 'x' });
  assert.equal(admin.user.role, 'admin');
  assert.equal((await call('GET', '/api/admin/stats', null, cust.token)).status, 403);
  const pend = await call('GET', '/api/admin/technicians?status=pending', null, admin.token);
  assert.ok(pend.technicians.some((x) => x.id === t.user.id));
  await call('POST', `/api/admin/technicians/${t.user.id}/review`, { approve: true }, admin.token);
  assert.equal((await call('POST', `/api/requests/${id}/bids`, { price: 100 }, t.token)).status, 'open');

  // شحن المحفظة وحد المديونية
  await call('POST', '/api/admin/wallet', { tech_id: t.user.id, amount: -250, note: 'تجربة' }, admin.token);
  assert.equal((await call('POST', `/api/requests/${id}/bids`, { price: 90 }, t.token)).status, 403);
  await call('POST', '/api/admin/wallet', { tech_id: t.user.id, amount: 300 }, admin.token);
  assert.equal((await call('POST', `/api/requests/${id}/bids`, { price: 90 }, t.token)).status, 'open');
});

test('التحقق من المدخلات والرفع والشكاوى', async () => {
  const cust = await signup('customer', 'عميل 5');
  assert.equal((await call('POST', '/api/requests', { ...reqBody, lat: 0, lng: 0 }, cust.token)).status, 400, 'خارج المناطق');
  assert.equal((await call('POST', '/api/requests', { ...reqBody, description: '' }, cust.token)).status, 400);
  assert.equal((await call('POST', '/api/requests', { ...reqBody, photos: ['http://evil/x.png'] }, cust.token)).status, 400);
  assert.equal((await call('POST', '/api/uploads', { data: Buffer.from('not an image'.repeat(20)).toString('base64') }, cust.token)).status, 400);
  const png = Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), Buffer.alloc(200)]);
  const up = await call('POST', '/api/uploads', { data: png.toString('base64') }, cust.token);
  assert.match(up.url, /^\/uploads\/public\/.+\.png$/);
  const f = await fetch(base + up.url);
  assert.equal(f.status, 200);
  const idUp = await call('POST', '/api/uploads', { data: png.toString('base64'), kind: 'id' }, cust.token);
  assert.equal((await fetch(base + idUp.url)).status, 401, 'ملف الهوية خاص');
  assert.equal((await fetch(base + idUp.url, { headers: { authorization: `Bearer ${cust.token}` } })).status, 200);

  const { id } = await call('POST', '/api/requests', reqBody, cust.token);
  assert.equal((await call('POST', `/api/requests/${id}/complaint`, { text: 'شكوى تجريبية' }, cust.token)).status, 200);
  const other = await signup('customer', 'غريب');
  assert.equal((await call('POST', `/api/requests/${id}/complaint`, { text: 'شكوى غريبة' }, other.token)).status, 404);
  assert.equal((await call('GET', `/api/requests/${id}`, null, other.token)).status, 403);
  for (const u of ['/../../etc/passwd', '/%2e%2e/%2e%2e/etc/passwd', '/..%2f..%2fetc/passwd', '/uploads/public/..%2f..%2fprivate%2fx']) {
    const t = await (await fetch(base + u)).text();
    assert.ok(!t.includes('root:'), 'تسرّب ملف نظام: ' + u);
  }
});

test('حذف الحساب وتخديم assetlinks', async () => {
  const c = await signup('customer', 'سيُحذف');
  assert.equal((await call('DELETE', '/api/me', null, c.token)).ok, true);
  assert.equal((await call('GET', '/api/me', null, c.token)).status, 401);
  const al = await fetch(base + '/.well-known/assetlinks.json');
  assert.equal(al.status, 200);
  assert.equal((await al.json())[0].target.package_name, 'net.dellini.mihnati');
});
