// اختبار شامل بالمتصفح: node tools/e2e.cjs   (يتطلب playwright + chromium)
const { spawn } = require('node:child_process');
const path = require('node:path'), fs = require('node:fs');
const { chromium } = require(process.env.PW_PATH || 'playwright');
const assert = require('node:assert/strict');
const root = path.resolve(__dirname, '..'), out = process.env.SHOTS || '/tmp/shots';
fs.mkdirSync(out, { recursive: true });
const PORT = 3111, BASE = `http://127.0.0.1:${PORT}`;
const geo = { latitude: 18.3093, longitude: 42.7298 };

(async () => {
  fs.rmSync('/tmp/e2e.db', { force: true }); fs.rmSync('/tmp/e2e.db-wal', { force: true }); fs.rmSync('/tmp/e2e.db-shm', { force: true });
  const srv = spawn('node', ['--disable-warning=ExperimentalWarning', 'server/src/index.js'], { cwd: root, env: { ...process.env, PORT, SHOW_OTP: '1', SEED_DEMO: '1', ADMIN_PHONE: '0500000000', SQLITE_PATH: '/tmp/e2e.db', UPLOAD_DIR: '/tmp/e2e-up', APP_SECRET: 'e2e', NODE_ENV: 'development', NO_PROXY: '127.0.0.1' }, stdio: ['ignore', 'pipe', 'inherit'] });
  await new Promise((r) => srv.stdout.on('data', (d) => /يعمل/.test(d) && r()));
  const browser = await chromium.launch();
  const errors = [];
  const mk = async (opts = {}) => {
    const ctx = await browser.newContext({ locale: 'ar-SA', geolocation: geo, permissions: ['geolocation'], viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, ...opts });
    const p = await ctx.newPage();
    p.on('pageerror', (e) => errors.push('pageerror: ' + e.message));
    p.on('console', (m) => m.type() === 'error' && !/unpkg|openstreetmap|ERR_|Failed to load resource/.test(m.text()) && errors.push('console: ' + m.text()));
    return p;
  };
  const dialogs = (p) => p.on('dialog', (d) => d.accept('قرار تجريبي'));
  async function login(p, phone, name, role) {
    await p.fill('#ph', phone); await p.click('#go');
    await p.waitForSelector('#code');
    const code = (await p.textContent('.card')).match(/تجريبي: (\d{6})/)[1];
    await p.fill('#code', code);
    if (name) { await p.fill('#nm', name); if (role === 'technician') await p.click('[data-r=technician]'); }
    await p.click('#ok');
  }
  try {
    // ---- العميل (جوال) ----
    const A = await mk(); dialogs(A);
    await A.goto(BASE + '/');
    await A.waitForSelector('.cat');
    assert.equal(await A.locator('.cat').count(), 6, '6 تصنيفات');
    await A.screenshot({ path: `${out}/01-home-mobile.png` });
    await A.click('.cat >> text=فني تكييف');
    await A.waitForSelector('#ph'); // صفحة الدخول (حقل الجوال)
    await login(A, '0553333333', 'سعد العميل', 'customer');
    await A.waitForSelector('#send');
    await A.fill('#t', 'المكيف لا يبرّد');
    await A.fill('#d', 'مكيف سبليت 24 وحدة لا يبرّد منذ يومين ويصدر صوتاً');
    await A.click('#loc'); await A.waitForSelector('text=تم تحديد موقعك');
    await A.selectOption('#m', '15');
    await A.screenshot({ path: `${out}/02-new-request-mobile.png` });
    await A.click('#send');
    await A.waitForURL(/#\/r\//);
    await A.waitForSelector('.timer');
    const reqUrl = A.url();
    console.log('✓ العميل نشر الطلب', reqUrl.split('#')[1]);

    // ---- الفنيان ----
    const T1 = await mk(); dialogs(T1);
    await T1.goto(BASE + '/#/login'); await login(T1, '0550000001');
    await T1.waitForSelector('text=الطلبات المتاحة'); await T1.waitForSelector('.card >> text=المكيف لا يبرّد');
    await T1.click('.card >> text=المكيف لا يبرّد'); await T1.waitForSelector('#bp');
    await T1.fill('#bp', '300'); await T1.selectOption('#bw', '30'); await T1.click('[data-act=bid]');
    await T1.waitForSelector('text=عرضي'); console.log('✓ الفني 1 قدّم 300');

    const T2 = await mk(); dialogs(T2);
    await T2.goto(BASE + '/#/login'); await login(T2, '0550000002');
    await T2.waitForSelector('.card >> text=المكيف لا يبرّد'); await T2.click('.card >> text=المكيف لا يبرّد'); await T2.waitForSelector('#bp');
    await T2.fill('#bp', '245'); await T2.click('[data-act=bid]'); await T2.waitForSelector('text=عرضي');
    // الفني 1 يرى أن السعر الأقل 245 ويخفض
    await T1.waitForSelector('text=تم تجاوز عرضك', { timeout: 8000 }).catch(() => {});
    await T1.reload(); await T1.waitForSelector('#bp'); await T1.fill('#bp', '260'); await T1.click('[data-act=bid]'); await T1.waitForSelector('text=٢٦٠');
    assert.ok((await T1.textContent('main')).includes('٢٤٥'), 'الفني يرى أقل سعر');
    console.log('✓ الفني 2 قدّم 245، الفني 1 خفض إلى 260');

    // ---- العميل يرى العروض لحظياً ----
    await A.waitForSelector('.bid.low', { timeout: 8000 });
    const lowText = await A.textContent('.bid.low');
    assert.ok(lowText.includes('فني تخصصين') && lowText.includes('٢٤٥'), 'الأقل سعراً هو 245: ' + lowText);
    await A.screenshot({ path: `${out}/03-request-bids-mobile.png`, fullPage: true });
    await A.click('[data-act=close]'); await A.waitForSelector('text=الفني: فني تخصصين');
    assert.ok((await A.textContent('main')).includes('+966550000002'), 'يظهر رقم الفائز');
    assert.ok(!(await A.textContent('main')).includes('+966550000001'), 'لا يظهر رقم الخاسر');
    console.log('✓ فاز الأقل (245) وظهر رقمه');

    // ---- الفني الفائز ينهي العمل ----
    await T2.reload(); await T2.waitForSelector('[data-act=status]');
    assert.ok((await T2.textContent('main')).includes('+966553333333'), 'الفائز يرى جوال العميل');
    for (const label of ['أنا في الطريق', 'وصلت إلى الموقع', 'بدء العمل', 'تم إنهاء العمل']) { await T2.click(`[data-act=status]`); await T2.waitForTimeout(400); }
    await T2.waitForSelector('text=مكتمل');
    await A.reload(); await A.waitForSelector('#stars');
    await A.click('#stars button[data-n="5"]'); await A.click('#tags .chip >> nth=0'); await A.fill('#rc', 'خدمة ممتازة');
    await A.click('[data-act=review]'); await A.waitForSelector('text=تقييمك');
    await A.screenshot({ path: `${out}/04-completed-mobile.png`, fullPage: true });
    console.log('✓ اكتمل العمل وقُيّم');

    // المحفظة: عمولة 10% من 245 = 25 (24.5 تقرّب إلى 25)
    await T2.goto(BASE + '/#/wallet'); await T2.waitForSelector('text=عمولة المنصة');
    await T2.screenshot({ path: `${out}/05-wallet-mobile.png` });
    await T2.goto(BASE + '/#/tech'); await T2.waitForSelector('text=1 عمل');

    // ---- نقطة القريبين ----
    await T2.click('#on'); await T2.waitForSelector('text=متصل — تظهر');
    await A.goto(BASE + '/#/nearby'); await A.waitForSelector('#list .card', { timeout: 8000 });
    await A.screenshot({ path: `${out}/06-nearby-mobile.png` });

    // ---- الإدارة ----
    const AD = await mk({ viewport: { width: 1440, height: 900 }, deviceScaleFactor: 1 }); dialogs(AD);
    await AD.goto(BASE + '/#/login'); await login(AD, '0500000000');
    await AD.waitForSelector('text=لوحة الإدارة'); await AD.screenshot({ path: `${out}/07-admin-laptop.png`, fullPage: true });
    assert.ok((await AD.textContent('main')).includes('العمولات'));

    // ---- فني جديد: توثيق واعتماد ----
    const T3 = await mk(); dialogs(T3);
    await T3.goto(BASE + '/#/login'); await login(T3, '0554444444', 'فني جديد', 'technician');
    await T3.waitForSelector('#idn');
    await T3.fill('#idn', '1098765432');
    const png = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==', 'base64');
    await T3.setInputFiles('#idp', { name: 'id.png', mimeType: 'image/png', buffer: png });
    await T3.waitForSelector('text=تم رفع الصورة');
    await T3.click('#cc .chip >> nth=1'); await T3.click('#zz .chip >> text=خميس مشيط'); await T3.click('#sv');
    await T3.waitForSelector('text=قيد مراجعة');
    await AD.reload(); await AD.waitForSelector('text=فني جديد'); await AD.click('[data-ap]');
    await T3.reload(); await T3.waitForFunction(() => !document.body.textContent.includes('قيد مراجعة'), null, { timeout: 8000 });
    console.log('✓ اعتماد فني جديد من الإدارة');

    // ---- أحجام الشاشات ----
    for (const [name, vp] of [['tablet', { width: 820, height: 1180 }], ['laptop', { width: 1440, height: 900 }]]) {
      const P = await mk({ viewport: vp, deviceScaleFactor: 1 });
      await P.goto(BASE + '/'); await P.waitForSelector('.cat'); await P.screenshot({ path: `${out}/08-home-${name}.png` });
    }
    const L = await mk({ viewport: { width: 1440, height: 900 }, deviceScaleFactor: 1 });
    await L.goto(BASE + '/#/login'); await login(L, '0553333333');
    await L.goto(BASE + reqUrl.split(BASE)[1]); await L.waitForSelector('.bid'); await L.screenshot({ path: `${out}/09-request-laptop.png` });

    await A.goto(BASE + '/privacy'); assert.ok((await A.textContent('body')).includes('سياسة الخصوصية'));
    assert.deepEqual(errors, [], 'أخطاء في الواجهة: ' + errors.join(' | '));
    console.log('✅ كل سيناريوهات المتصفح نجحت');
  } catch (e) {
    console.error('❌', e.message.split('\n').slice(0, 6).join('\n'), '\nأخطاء الواجهة:', errors);
    process.exitCode = 1;
  } finally { await browser.close(); srv.kill(); }
})();
